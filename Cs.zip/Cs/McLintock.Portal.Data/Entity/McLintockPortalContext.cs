﻿namespace McLintock.Portal.Data.Entity
{
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Data.Util;
    using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Database context for the portal.
    /// </summary>
    public class McLintockPortalContext : IdentityDbContext<ApplicationIdentityUser, ApplicationRole, int>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="McLintockPortalContext"/> class.
        /// </summary>
        /// <param name="options">The context configuration info.</param>
        public McLintockPortalContext(DbContextOptions options)
            : base(options)
        {
        }

        /// <summary>
        /// Gets or sets a collection of posts.
        /// </summary>
        public DbSet<Post> Posts { get; set; }

        /// <summary>
        /// Gets or sets a collection of post logs.
        /// </summary>
        public DbSet<PostLog> PostLogs { get; set; }

        /// <summary>
        /// Gets or sets a collection of post log tags.
        /// </summary>
        public DbSet<PostLogTag> PostLogTags { get; set; }

        /// <summary>
        /// Gets or sets a collection of post tags.
        /// </summary>
        public DbSet<PostTag> PostTags { get; set; }

        /// <summary>
        /// Gets or sets a collection of post user groups.
        /// </summary>
        public DbSet<PostUserGroup> PostUserGroups { get; set; }

        /// <summary>
        /// Gets or sets a collection of tags.
        /// </summary>
        public DbSet<Tag> Tags { get; set; }

        /// <summary>
        /// Gets or sets a collection of user groups.
        /// </summary>
        public DbSet<UserGroup> UserGroups { get; set; }

        /// <summary>
        /// Gets or sets a collection of user group members.
        /// </summary>
        public DbSet<UserGroupMember> UserGroupMembers { get; set; }

        /// <summary>
        /// Provide the additonal info required to build the database.
        /// </summary>
        /// <param name="builder">ModelBuilder Api.</param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<ApplicationIdentityUser>(entity =>
            {
            });

            builder.Entity<Post>(entity =>
            {
                entity.HasIndex(e => e.Created).HasDatabaseName("IX_Created");

                entity.HasIndex(e => e.CreatedByUserId).HasDatabaseName("IX_CreatedByUserId");

                entity.HasIndex(e => e.ModifiedByUserId).HasDatabaseName("IX_ModifiedByUserId");

                entity.Property(p => p.Content).IsRequired();

                entity.Property(p => p.Created).HasColumnType("datetime");

                entity.Property(p => p.Modified).HasColumnType("datetime");

                entity.Property(p => p.Title)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.HasOne(e => e.CreatedByUser)
                    .WithMany(e => e.PostsCreated)
                    .HasForeignKey(e => e.CreatedByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(e => e.ModifiedByUser)
                    .WithMany(e => e.PostsModified)
                    .HasForeignKey(e => e.ModifiedByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            builder.Entity<PostLog>(entity =>
            {
                entity.HasIndex(e => e.PostId).HasDatabaseName("IX_PostId");

                entity.HasIndex(e => e.UserId).HasDatabaseName("IX_UserId");

                entity.HasIndex(e => e.Timestamp).HasDatabaseName("IX_Timestamp");

                entity.Property(e => e.Timestamp).HasColumnType("datetime");

                entity.HasOne(e => e.Post)
                    .WithMany(e => e.PostLogs)
                    .HasForeignKey(e => e.PostId);

                entity.HasOne(e => e.User)
                    .WithMany(e => e.PostLogs)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            builder.Entity<PostLogTag>(entity =>
            {
                entity.HasIndex(e => e.PostLogId).HasDatabaseName("IX_PostLogId");

                entity.HasIndex(e => e.TagId).HasDatabaseName("IX_TagId");
            });

            builder.Entity<PostTag>(entity =>
            {
                entity.HasKey(e => new { e.PostId, e.TagId });

                entity.HasIndex(e => e.PostId).HasDatabaseName("IX_PostId");

                entity.HasIndex(e => e.TagId).HasDatabaseName("IX_TagId");

                entity.HasOne(e => e.Post)
                    .WithMany(e => e.PostTags)
                    .HasForeignKey(e => e.PostId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_dbo.PostTags_dbo.Posts_PostId");

                entity.HasOne(e => e.Tag)
                    .WithMany(e => e.PostTags)
                    .HasForeignKey(e => e.TagId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_dbo.PostTags_dbo.Tags_TagId");
            });

            builder.Entity<PostUserGroup>(entity =>
            {
                entity.HasKey(e => new { e.PostId, e.UserGroupId });
            });

            builder.Entity<Tag>(entity =>
            {
                entity.HasIndex(e => e.Name)
                    .IsUnique()
                    .HasDatabaseName("IX_Name");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            builder.Entity<UserGroup>(entity =>
            {
                entity.HasIndex(e => e.UserId).HasDatabaseName("IX_UserId");

                entity.HasIndex(e => new { e.UserId, e.Name })
                    .IsUnique()
                    .HasDatabaseName("IX_UserId_Name");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            builder.Entity<UserGroupMember>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.UserGroupId });

                entity.HasIndex(e => e.UserGroupId).HasDatabaseName("IX_UserGroupId");

                entity.HasIndex(e => e.UserId).HasDatabaseName("IX_UserId");

                entity.HasOne(e => e.UserGroup)
                    .WithMany(e => e.UserGroupMembers)
                    .HasForeignKey(e => e.UserGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(e => e.User)
                    .WithMany(e => e.UserGroupMembers)
                    .HasForeignKey(e => e.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            // Configure value generator for in memory testing
            if (Database.IsInMemory())
            {
                builder.Entity<Post>()
                    .Property(o => o.Id)
                    .HasValueGenerator<MaxPlusOneValueGenerator<Post>>();

                builder.Entity<PostLog>()
                    .Property(o => o.Id)
                    .HasValueGenerator<MaxPlusOneValueGenerator<PostLog>>();

                builder.Entity<PostLogTag>()
                    .Property(o => o.Id)
                    .HasValueGenerator<MaxPlusOneValueGenerator<PostLogTag>>();

                builder.Entity<Tag>()
                    .Property(o => o.Id)
                    .HasValueGenerator<MaxPlusOneValueGenerator<Tag>>();

                builder.Entity<UserGroup>()
                    .Property(o => o.Id)
                    .HasValueGenerator<MaxPlusOneValueGenerator<UserGroup>>();
            }
        }
    }
}
