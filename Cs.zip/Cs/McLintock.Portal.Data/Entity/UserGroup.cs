﻿namespace McLintock.Portal.Data.Entity
{
    using System.Collections.Generic;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Data.Identity;

    /// <summary>
    /// User group entity.
    /// </summary>
    public class UserGroup : IEntity, INamedEntity
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserGroup"/> class.
        /// </summary>
        public UserGroup()
        {
            PostUserGroups = new HashSet<PostUserGroup>();
            UserGroupMembers = new HashSet<UserGroupMember>();
        }

        /// <inheritdoc/>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the user group name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the user id of the group owner.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        public virtual ApplicationIdentityUser User { get; set; }

        /// <summary>
        /// Gets or sets the collection of post user groups.
        /// </summary>
        public virtual ICollection<PostUserGroup> PostUserGroups { get; set; }

        /// <summary>
        /// Gets or sets the collection of user group members.
        /// </summary>
        public virtual ICollection<UserGroupMember> UserGroupMembers { get; set; }
    }
}
