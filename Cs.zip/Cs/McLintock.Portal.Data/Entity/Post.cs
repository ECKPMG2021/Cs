﻿namespace McLintock.Portal.Data.Entity
{
    using System;
    using System.Collections.Generic;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Data.Identity;

    /// <summary>
    /// Post entity.
    /// </summary>
    public class Post : IEntity, IAudit
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Post"/> class.
        /// </summary>
        public Post()
        {
            PostLogs = new List<PostLog>();
            PostTags = new HashSet<PostTag>();
            PostUserGroups = new HashSet<PostUserGroup>();
        }

        /// <inheritdoc/>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post title.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the post content.
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the post is public.
        /// </summary>
        public bool IsPublic { get; set; }

        /// <summary>
        /// Gets or sets the created by user id.
        /// </summary>
        public int CreatedByUserId { get; set; }

        /// <summary>
        /// Gets or sets the created time.
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the modified by user id.
        /// </summary>
        public int ModifiedByUserId { get; set; }

        /// <summary>
        /// Gets or sets the modified time.
        /// </summary>
        public DateTime Modified { get; set; }

        /// <summary>
        /// Gets or sets the created by user.
        /// </summary>
        public virtual ApplicationIdentityUser CreatedByUser { get; set; }

        /// <summary>
        /// Gets or sets the modified by user.
        /// </summary>
        public virtual ApplicationIdentityUser ModifiedByUser { get; set; }

        /// <summary>
        /// Gets or sets the collection of post logs.
        /// </summary>
        public virtual ICollection<PostLog> PostLogs { get; set; }

        /// <summary>
        /// Gets or sets the collection of post tags.
        /// </summary>
        public virtual ICollection<PostTag> PostTags { get; set; }

        /// <summary>
        /// Gets or sets the collection of post user groups.
        /// </summary>
        public virtual ICollection<PostUserGroup> PostUserGroups { get; set; }
    }
}
