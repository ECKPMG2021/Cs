﻿namespace McLintock.Portal.Data.Entity
{
    using McLintock.Portal.Data.Identity;

    /// <summary>
    /// User group member entity, used to associate users with groups.
    /// </summary>
    public class UserGroupMember
    {
        /// <summary>
        /// Gets or sets the user group id.
        /// </summary>
        public int UserGroupId { get; set; }

        /// <summary>
        /// Gets or sets the user id.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the associated user.
        /// </summary>
        public virtual ApplicationIdentityUser User { get; set; }

        /// <summary>
        /// Gets or sets the associated user group.
        /// </summary>
        public virtual UserGroup UserGroup { get; set; }
    }
}
