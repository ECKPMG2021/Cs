﻿namespace McLintock.Portal.Data.Entity
{
    using System;
    using System.Collections.Generic;
    using McLintock.Portal.Data.Identity;

    /// <summary>
    /// Post log.
    /// </summary>
    public class PostLog
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post Id.
        /// </summary>
        public int PostId { get; set; }

        /// <summary>
        /// Gets or sets the timestamp.
        /// </summary>
        public DateTime Timestamp { get; set; }

        /// <summary>
        /// Gets or sets the reader Id.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the post.
        /// </summary>
        public Post Post { get; set; }

        /// <summary>
        /// Gets or sets the post log tags.
        /// </summary>
        public virtual ICollection<PostLogTag> Tags { get; set; }

        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        public virtual ApplicationIdentityUser User { get; set; }
    }
}
