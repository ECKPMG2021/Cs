﻿namespace McLintock.Portal.Data.Entity
{
    /// <summary>
    /// Post log tag.
    /// </summary>
    public class PostLogTag
    {
        /// <summary>
        /// Gets or sets the Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post log Id.
        /// </summary>
        public int PostLogId { get; set; }

        /// <summary>
        /// Gets or sets the tag Id.
        /// </summary>
        public int TagId { get; set; }

        /// <summary>
        /// Gets or sets the post log.
        /// </summary>
        public PostLog PostLog { get; set; }

        /// <summary>
        /// Gets or sets the tag.
        /// </summary>
        public Tag Tag { get; set; }
    }
}
