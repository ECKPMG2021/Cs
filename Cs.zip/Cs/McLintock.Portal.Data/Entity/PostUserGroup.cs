﻿namespace McLintock.Portal.Data.Entity
{
    /// <summary>
    /// Post user group entity.
    /// </summary>
    public class PostUserGroup
    {
        /// <summary>
        /// Gets or sets the post id.
        /// </summary>
        public int PostId { get; set; }

        /// <summary>
        /// Gets or sets the user group id.
        /// </summary>
        public int UserGroupId { get; set; }

        /// <summary>
        /// Gets or sets the post.
        /// </summary>
        public virtual Post Post { get; set; }

        /// <summary>
        /// Gets or sets the user group.
        /// </summary>
        public virtual UserGroup UserGroup { get; set; }
    }
}
