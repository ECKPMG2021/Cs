﻿namespace McLintock.Portal.Data.Entity
{
    using System.Collections.Generic;
    using McLintock.Portal.Core.Interfaces;

    /// <summary>
    /// Tag entity.
    /// </summary>
    public class Tag : IEntity, INamedEntity
    {
        /// <inheritdoc/>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the tag name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the collection of posts associated with the tag.
        /// </summary>
        public virtual ICollection<PostTag> PostTags { get; set; }

        /// <summary>
        /// Gets or sets the collection of posts log tags associated with the tag.
        /// </summary>
        public virtual ICollection<PostLogTag> PostLogTags { get; set; }
    }
}
