﻿namespace McLintock.Portal.Data.Entity
{
    /// <summary>
    /// Post tag entity, tracks the tags associated with each post.
    /// </summary>
    public class PostTag
    {
        /// <summary>
        /// Gets or sets the post id.
        /// </summary>
        public int PostId { get; set; }

        /// <summary>
        /// Gets or sets the tag id.
        /// </summary>
        public int TagId { get; set; }

        /// <summary>
        /// Gets or sets the associated post.
        /// </summary>
        public virtual Tag Tag { get; set; }

        /// <summary>
        /// Gets or sets the associated tag.
        /// </summary>
        public virtual Post Post { get; set; }
    }
}
