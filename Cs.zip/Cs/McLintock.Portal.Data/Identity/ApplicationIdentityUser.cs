﻿namespace McLintock.Portal.Data.Identity
{
    using System.Collections.Generic;
    using McLintock.Portal.Data.Entity;
    using Microsoft.AspNetCore.Identity;

    /// <summary>
    /// Application identity user entity.
    /// </summary>
    public class ApplicationIdentityUser : IdentityUser<int>
    {
        /// <summary>
        /// Gets or sets the collection of posts the user created.
        /// </summary>
        public virtual ICollection<Post> PostsCreated { get; set; }

        /// <summary>
        /// Gets or sets the collection of posts the user has modified.
        /// </summary>
        public virtual ICollection<Post> PostsModified { get; set; }

        /// <summary>
        /// Gets or sets the collection of post logs associated with the user.
        /// </summary>
        public virtual ICollection<PostLog> PostLogs { get; set; }

        /// <summary>
        /// Gets or sets the collection of user groups associated with the user.
        /// </summary>
        public virtual ICollection<UserGroup> UserGroups { get; set; }

        /// <summary>
        /// Gets or sets the collection of user groups with the user is included in.
        /// </summary>
        public virtual ICollection<UserGroupMember> UserGroupMembers { get; set; }
    }
}
