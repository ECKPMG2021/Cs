﻿namespace McLintock.Portal.Data.Identity
{
    using Microsoft.AspNetCore.Identity;

    /// <summary>
    /// Application role entity.
    /// </summary>
    public class ApplicationRole : IdentityRole<int>
    {
    }
}
