﻿namespace McLintock.Portal.Data.Util
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.ChangeTracking;
    using Microsoft.EntityFrameworkCore.ValueGeneration;

    /// <summary>
    /// MaxPlusOneValueGenerator.
    /// </summary>
    /// <typeparam name="TEntity">Db Entity.</typeparam>
    public class MaxPlusOneValueGenerator<TEntity> : ValueGenerator<int>
        where TEntity : class
    {
        private static MethodInfo generic;
        private static Dictionary<string, int> keyTracker;

        // statically set the MethodInfo for GetMaxKeyValue
        static MaxPlusOneValueGenerator()
        {
            var method = typeof(DbContext).GetMethod("Set");
            generic = method.MakeGenericMethod(typeof(TEntity));
            keyTracker = new Dictionary<string, int>();
        }

        /// <summary>
        /// Gets a value indicating whether values are overridden by the database
        /// (since this class is used for testing, values are not written to the database).
        /// </summary>
        public override bool GeneratesTemporaryValues => false;

        /// <summary>
        /// Gets the next value for the ID of the entity. The
        /// next value is always 1 + current maximum.
        /// </summary>
        /// <param name="entry">The entry that will be written to the test database.</param>
        /// <returns>max plus 1.</returns>
        public override int Next(EntityEntry entry)
        {
            var context = entry.Context;
            var qry = generic.Invoke(context, null) as DbSet<TEntity>;
            var typeName = entry.Entity.GetType().ToString();

            if (!qry.Any())
            {
                // No entries saved but there may be some added and tracked locally
                if (keyTracker.Keys.Any(k => k == typeName))
                {
                    keyTracker[typeName] = ++keyTracker[typeName];
                }
                else
                {
                    keyTracker[typeName] = 1;
                }

                return keyTracker[typeName];
            }

            var key1Name = GetKeyName(entry);

            var currentMax = qry.Max(e =>
                (int)e.GetType()
                      .GetProperty(key1Name)
                      .GetValue(e));

            if (keyTracker.Keys.Any(k => k == typeName) && currentMax <= keyTracker[typeName])
            {
                // If the tracked value is greater than the key obtained from the db,
                // increment it as multiple entities may be getting added and the set
                // will not track this until the changes are saved
                currentMax = keyTracker[typeName];
            }

            keyTracker[typeName] = currentMax + 1;

            return keyTracker[typeName];
        }

        private static string GetKeyName(EntityEntry entry)
        {
            return entry.Metadata
                        .FindPrimaryKey()
                        .Properties
                        .First()
                        .Name;
        }
    }
}
