﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace McLintock.Portal.Data.Migrations
{
    public partial class UpdatedConstraints : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_dbo.PostTags_dbo.Posts_PostId",
                table: "PostTags");

            migrationBuilder.DropForeignKey(
                name: "FK_dbo.PostTags_dbo.Tags_TagId",
                table: "PostTags");

            migrationBuilder.AddForeignKey(
                name: "FK_dbo.PostTags_dbo.Posts_PostId",
                table: "PostTags",
                column: "PostId",
                principalTable: "Posts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_dbo.PostTags_dbo.Tags_TagId",
                table: "PostTags",
                column: "TagId",
                principalTable: "Tags",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_dbo.PostTags_dbo.Posts_PostId",
                table: "PostTags");

            migrationBuilder.DropForeignKey(
                name: "FK_dbo.PostTags_dbo.Tags_TagId",
                table: "PostTags");

            migrationBuilder.AddForeignKey(
                name: "FK_dbo.PostTags_dbo.Posts_PostId",
                table: "PostTags",
                column: "PostId",
                principalTable: "Posts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_dbo.PostTags_dbo.Tags_TagId",
                table: "PostTags",
                column: "TagId",
                principalTable: "Tags",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
