﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Post log repository.
    /// </summary>
    public class PostLogRepository : IPostLogRepository
    {
        private readonly McLintockPortalContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostLogRepository"/> class.
        /// </summary>
        /// <param name="context">McLintockPortalContext instance.</param>
        public PostLogRepository(McLintockPortalContext context)
        {
            _context = context ?? throw new ArgumentNullException("context");
        }

        /// <inheritdoc/>
        public async Task AddPostLogAsync(PostLog log)
        {
            _context.PostLogs.Add(log);
            await _context.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task<StatsViewModel> GetPostStatsAsync(int postId, int userId, int days)
        {
            var model = new StatsViewModel();
            var startDate = DateTime.Today.AddDays(-days);

            var post = await _context.Posts.SingleOrDefaultAsync(p =>
                p.Id == postId && p.CreatedByUserId == userId);

            if (post == null)
            {
                return model;
            }

            model.Id = postId;
            model.Name = post.Title;
            model.Items = await _context.PostLogs
                .Where(l => l.Timestamp >= startDate
                         && l.PostId == postId
                         && l.Post.CreatedByUserId == userId)
                .GroupBy(l => l.Timestamp.Date)
                .Select(l => new StatsItemViewModel
                {
                    Date = l.Key,
                    Users = l.Select(u => u.UserId).Distinct().Count(),
                    Views = l.Count(),
                })
                .ToListAsync();

            return model;
        }

        /// <inheritdoc/>
        public async Task<List<PostUsageSummaryModel>> GetPostUsageSummaryAsync(int userId)
        {
            var model = await SecuredPosts(userId)
                .Select(p => new PostUsageSummaryModel
                {
                    Id = p.Id,
                    Title = p.Title,
                    Users = p.PostLogs.Select(l => l.UserId).Distinct().Count(),
                    Views = p.PostLogs.Count()
                }).ToListAsync();

            return model;
        }

        /// <inheritdoc/>
        public async Task<StatsViewModel> GetTagStatsAsync(int tagId, int userId, int days)
        {
            var model = new StatsViewModel();
            var startDate = DateTime.Today.AddDays(-days);

            var tag = await _context.Tags.SingleOrDefaultAsync(p =>
                p.Id == tagId);

            if (tag == null)
            {
                return model;
            }

            model.Id = tagId;
            model.Name = tag.Name;
            model.Items = await SecuredPosts(userId)
                .SelectMany(l => l.PostLogs.SelectMany(t => t.Tags))
                .Where(l => l.PostLog.Timestamp >= startDate
                         && l.TagId == tagId)
                .GroupBy(l => l.PostLog.Timestamp.Date)
                .Select(l => new StatsItemViewModel
                {
                    Date = l.Key,
                    Users = l.Select(u => u.PostLog.UserId).Distinct().Count(),
                    Views = l.Count(),
                })
                .ToListAsync();

            return model;
        }

        /// <inheritdoc/>
        public async Task<List<TagUsageSummaryModel>> GetTagUsageSummaryAsync(int userId)
        {
            var model = await SecuredPosts(userId)
                .SelectMany(t => t.PostLogs)
                .SelectMany(t => t.Tags)
                .GroupBy(t => new { t.Tag.Id, t.Tag.Name })
                .Select(t => new TagUsageSummaryModel
                {
                    Posts = t.Select(p => p.PostLog.PostId).Distinct().Count(),
                    Id = t.Key.Id,
                    Name = t.Key.Name,
                    Views = t.Count(),
                }).ToListAsync();

            return model;
        }

        private IQueryable<Post> SecuredPosts(int userId)
        {
            return _context.Posts
                 .Where(p => p.CreatedByUserId == userId
                          || p.IsPublic
                          || p.PostUserGroups.Any(g => g.UserGroup.UserGroupMembers.Any(m => m.UserId == userId)));
        }
    }
}
