﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// User group repository.
    /// </summary>
    public interface IUserGroupRepository : IRepository<UserGroup>
    {
        /// <summary>
        /// Gets the list of user groups the user has created.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of user groups.</returns>
        Task<List<UserGroup>> GetByUserIdAsync(int userId);
    }
}
