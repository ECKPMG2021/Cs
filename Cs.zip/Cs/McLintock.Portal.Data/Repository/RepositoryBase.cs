﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Repository base class.
    /// </summary>
    /// <typeparam name="T">Entity type.</typeparam>
    public class RepositoryBase<T> : IRepository<T>
        where T : class
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryBase{T}"/> class.
        /// </summary>
        /// <param name="context">The Db Context.</param>
        public RepositoryBase(McLintockPortalContext context) => Context = context ?? throw new ArgumentNullException("context");

        /// <summary>
        /// Gets the context instance.
        /// </summary>
        protected McLintockPortalContext Context { get; private set; }

        /// <inheritdoc/>
        public virtual void AddAllOnSubmit(IEnumerable<T> entities)
        {
            foreach (var entity in entities)
            {
                AddOnSubmit(entity);
            }
        }

        /// <inheritdoc/>
        public virtual void AddOnSubmit(T entity)
        {
            var entry = Context.Entry(entity);

            if (entry.State == EntityState.Detached)
            {
                Context.Set<T>().Add(entity);
            }
            else
            {
                entry.State = EntityState.Modified;
            }
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await Context.Set<T>().ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<T>> GetAllAsync(Expression<Func<T, bool>> predicate)
        {
            return await Context.Set<T>().Where(predicate).ToListAsync();
        }

        /// <inheritdoc/>
        public virtual async Task<T> GetAsync(Expression<Func<T, bool>> predicate)
        {
            return await Context.Set<T>().Where(predicate).SingleOrDefaultAsync();
        }

        /// <inheritdoc/>
        public virtual void RemoveAllOnSubmit(IEnumerable<T> entities)
        {
            foreach (var entity in entities)
            {
                RemoveOnSubmit(entity);
            }
        }

        /// <inheritdoc/>
        public virtual void RemoveOnSubmit(T entity)
        {
            var entry = Context.Entry(entity);

            if (entry.State == EntityState.Detached)
            {
                Context.Set<T>().Attach(entity);
            }

            Context.Entry<T>(entity).State = EntityState.Deleted;
        }

        /// <inheritdoc/>
        public virtual async Task SubmitChangesAsync()
        {
            await Context.SaveChangesAsync();
        }
    }
}
