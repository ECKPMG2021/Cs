﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Extensions;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Tag repository.
    /// </summary>
    public class TagRepository : RepositoryBase<Tag>, ITagRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TagRepository"/> class.
        /// </summary>
        /// <param name="context">McLintockPortalContext instance.</param>
        public TagRepository(McLintockPortalContext context)
            : base(context)
        {
        }

        /// <inheritdoc/>
        public async Task<List<Tag>> GetByUserIdAsync(int userId)
        {
            return await Context.PostTags
                                .Where(p => p.Post.CreatedByUserId == userId)
                                .Select(p => p.Tag)
                                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<Tag> GetOrCreateTagAsync(string tagName)
        {
            var cleansed = tagName.ToTagStandard();

            var tag = await Context.Tags.SingleOrDefaultAsync(t => t.Name.Equals(cleansed));

            if (tag == null)
            {
                tag = new Tag { Name = cleansed };
                AddOnSubmit(tag);
            }

            return tag;
        }

        /// <inheritdoc/>
        public async Task<List<ItemSelectViewModel>> GetTagSelectListItemsAsync(int userId)
        {
            var items = Context.Posts
                .Where(p => p.CreatedByUserId == userId)
                .SelectMany(p => p.PostTags.Select(t => t.Tag))
                .Select(t => new ItemSelectViewModel
                {
                    Id = t.Id,
                    Name = t.Name,
                });

            return await items.OrderBy(p => p.Name).ToListAsync();
        }
    }
}
