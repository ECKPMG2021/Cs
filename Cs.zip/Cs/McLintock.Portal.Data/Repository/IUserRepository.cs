﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Identity;

    /// <summary>
    /// User repository interface.
    /// </summary>
    public interface IUserRepository
    {
        /// <summary>
        /// Gets all users.
        /// </summary>
        /// <returns>List of users.</returns>
        Task<List<ApplicationIdentityUser>> GetAllUsersAsync();
    }
}