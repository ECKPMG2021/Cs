﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// Tag repository interface.
    /// </summary>
    public interface ITagRepository : IRepository<Tag>
    {
        /// <summary>
        /// Returns all of the tags that a user has used.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of tags.</returns>
        Task<List<Tag>> GetByUserIdAsync(int userId);

        /// <summary>
        /// Gets an tag or creates a new one if required.
        /// </summary>
        /// <param name="tagName">Tag name.</param>
        /// <returns>Tag.</returns>
        Task<Tag> GetOrCreateTagAsync(string tagName);

        /// <summary>
        /// Gets a list of items to populate a select list.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of item select view models.</returns>
        Task<List<ItemSelectViewModel>> GetTagSelectListItemsAsync(int userId);
    }
}