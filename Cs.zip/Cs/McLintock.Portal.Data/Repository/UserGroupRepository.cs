﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <inheritdoc/>
    public class UserGroupRepository : RepositoryBase<UserGroup>, IUserGroupRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserGroupRepository"/> class.
        /// </summary>
        /// <param name="context">McLintockPortalContext instance.</param>
        public UserGroupRepository(McLintockPortalContext context)
            : base(context)
        {
        }

        /// <inheritdoc/>
        public override async Task<UserGroup> GetAsync(Expression<Func<UserGroup, bool>> predicate)
        {
            return await UserGroupBase().Where(predicate).SingleOrDefaultAsync();
        }

        /// <inheritdoc/>
        public async Task<List<UserGroup>> GetByUserIdAsync(int userId)
        {
            return await UserGroupBase().Where(g => g.UserId == userId)
                                        .Include(i => i.UserGroupMembers)
                                            .ThenInclude(i => i.User)
                                        .ToListAsync();
        }

        private IQueryable<UserGroup> UserGroupBase()
        {
            return Context.UserGroups
                          .Include(i => i.UserGroupMembers)
                            .ThenInclude(i => i.User);
        }
    }
}
