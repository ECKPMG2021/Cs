﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    /// <summary>
    /// Generic base repository.
    /// </summary>
    /// <typeparam name="T">The entity type.</typeparam>
    public interface IRepository<T>
    {
        /// <summary>
        /// Adds entities to the collection.
        /// </summary>
        /// <param name="entities">Entities to add.</param>
        void AddAllOnSubmit(IEnumerable<T> entities);

        /// <summary>
        /// Adds an entity to the collection.
        /// </summary>
        /// <param name="entity">Entity to add.</param>
        void AddOnSubmit(T entity);

        /// <summary>
        /// Gets all entities of the specified type.
        /// </summary>
        /// <param name="predicate">Expression to find the entities.</param>
        /// <returns>A collection of entities of the specified type.</returns>
        Task<IEnumerable<T>> GetAllAsync();

        /// <summary>
        /// Gets all entities resulting from the predicate.
        /// </summary>
        /// <param name="predicate">Expression to find the entities.</param>
        /// <returns>A collection of entities of the specified type.</returns>
        Task<IEnumerable<T>> GetAllAsync(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Gets a single instance of the entity.
        /// </summary>
        /// <param name="predicate">Expression to find the entity.</param>
        /// <returns>A single entity of the specified type or null.</returns>
        Task<T> GetAsync(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Removes entities from the collection.
        /// </summary>
        /// <param name="entities">Entities to remove.</param>
        void RemoveAllOnSubmit(IEnumerable<T> entities);

        /// <summary>
        /// Removes an entity from the collection.
        /// </summary>
        /// <param name="entity">Entity to remove.</param>
        void RemoveOnSubmit(T entity);

        /// <summary>
        /// Persists and unsaved changes.
        /// </summary>
        /// <returns>Void.</returns>
        Task SubmitChangesAsync();
    }
}
