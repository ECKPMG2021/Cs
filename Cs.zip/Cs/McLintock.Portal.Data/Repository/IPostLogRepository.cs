﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// Post log repository interface.
    /// </summary>
    public interface IPostLogRepository
    {
        /// <summary>
        /// Logs the user and post view information.
        /// </summary>
        /// <param name="log">Post log entry.</param>
        /// <returns>Void.</returns>
        Task AddPostLogAsync(PostLog log);

        /// <summary>
        /// Gets the stats for the specified post.
        /// </summary>
        /// <param name="postId">Post Id.</param>
        /// <param name="userId">User Id.</param>
        /// <param name="days">Days to analyse.</param>
        /// <returns>Stats view model.</returns>
        Task<StatsViewModel> GetPostStatsAsync(int postId, int userId, int days);

        /// <summary>
        /// Gets that post stats based on the posts that the specified user id has visibility of.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>PostUsageSummaryModel.</returns>
        Task<List<PostUsageSummaryModel>> GetPostUsageSummaryAsync(int userId);

        /// <summary>
        /// Gets the stats for the specified tag.
        /// </summary>
        /// <param name="tagId">Tag Id.</param>
        /// <param name="userId">User Id.</param>
        /// <param name="days">Days to analyse.</param>
        /// <returns>Stats view model.</returns>
        Task<StatsViewModel> GetTagStatsAsync(int tagId, int userId, int days);

        /// <summary>
        /// Gets that tag summary based on the posts that the specified user id has visibility of.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>PostUsageSummaryModel.</returns>
        Task<List<TagUsageSummaryModel>> GetTagUsageSummaryAsync(int userId);
    }
}