﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Post entity repository.
    /// </summary>
    public class PostRepository : RepositoryBase<Post>, IPostRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostRepository"/> class.
        /// </summary>
        /// <param name="context">The Db Context.</param>
        public PostRepository(McLintockPortalContext context)
            : base(context)
        {
        }

        /// <inheritdoc/>
        public override async Task<Post> GetAsync(Expression<Func<Post, bool>> predicate)
        {
           throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public async Task<List<Post>> GetByUserIdAsync(int userId)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public async Task<List<Post>> GetPostsCreatedByUserAsync(int userId)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc/>
        public async Task<List<ItemSelectViewModel>> GetPostSelectListItemsAsync(int userId)
        {
            throw new NotImplementedException();
        }
    }
}
