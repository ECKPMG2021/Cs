﻿namespace McLintock.Portal.Data.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// User repository.
    /// </summary>
    public class UserRepository : IUserRepository
    {
        private readonly McLintockPortalContext _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserRepository"/> class.
        /// </summary>
        /// <param name="context">McLintockPortalContext instance.</param>
        public UserRepository(McLintockPortalContext context)
        {
            _context = context ?? throw new ArgumentNullException("context");
        }

        /// <summary>
        /// Gets all portal users.
        /// </summary>
        /// <returns>List of users.</returns>
        public async Task<List<ApplicationIdentityUser>> GetAllUsersAsync()
        {
            return await _context.Users.ToListAsync();
        }
    }
}
