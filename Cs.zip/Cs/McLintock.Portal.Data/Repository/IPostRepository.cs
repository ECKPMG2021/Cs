﻿namespace McLintock.Portal.Data.Repository
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// Post repository interface.
    /// </summary>
    public interface IPostRepository : IRepository<Post>
    {
        /// <summary>
        /// Get the collection of posts that the specified user can view.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>Collection of posts.</returns>
        Task<List<Post>> GetByUserIdAsync(int userId);

        /// <summary>
        /// Gets the collection of post created by the user.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>Collection of posts.</returns>
        Task<List<Post>> GetPostsCreatedByUserAsync(int userId);

        /// <summary>
        /// Gets a list of items to populate a select list.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of item select view models.</returns>
        Task<List<ItemSelectViewModel>> GetPostSelectListItemsAsync(int userId);
    }
}
