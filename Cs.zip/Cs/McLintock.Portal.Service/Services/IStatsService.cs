﻿namespace McLintock.Portal.Service.Services
{
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;

    /// <summary>
    /// Stats service interface.
    /// </summary>
    public interface IStatsService
    {
        /// <summary>
        /// Gets the stats for the specified post.
        /// </summary>
        /// <param name="id">Post id.</param>
        /// <param name="days">Days to report.</param>
        /// <returns>Stats view model.</returns>
        Task<StatsViewModel> GetPostStatsAsync(int id, int days);

        /// <summary>
        /// Gets the model required for the stats page.
        /// </summary>
        /// <param name="days">Days to report.</param>
        /// <returns>Stats page view model.</returns>
        Task<StatsPageViewModel> GetStatsAsync(int days);

        /// <summary>
        /// Gets the stats for the specified tag.
        /// </summary>
        /// <param name="id">Tag id.</param>
        /// <param name="days">Days to report.</param>
        /// <returns>Stats view model.</returns>
        Task<StatsViewModel> GetTagStatsAsync(int id, int days);
    }
}
