﻿namespace McLintock.Portal.Service.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;

    /// <summary>
    /// Post service interface.
    /// </summary>
    public interface IPostService : IService<PostViewModel>
    {
        /// <summary>
        /// Gets a post to display.
        /// </summary>
        /// <param name="id">Post Id.</param>
        /// <returns>Post view model.</returns>
        Task<PostViewModel> DetailsAsync(int id);

        /// <summary>
        /// Returns the list of posts the specified user has created.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of posts.</returns>
        Task<List<PostViewModel>> ListCreatedByUserAsync(int userId);

        /// <summary>
        /// Returns the list of posts the specified user is allowed to view.
        /// Along with summary information for all posts.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <param name="authorId">Author Id.</param>
        /// <param name="tagId">Tag Id.</param>
        /// <returns>List of posts.</returns>
        Task<PostSummaryViewModel> SummaryListAsync(int userId, int? authorId, int? tagId);
    }
}