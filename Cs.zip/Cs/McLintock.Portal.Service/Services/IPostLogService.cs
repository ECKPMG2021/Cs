﻿namespace McLintock.Portal.Service.Services
{
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Models;

    /// <summary>
    /// Post log service interface.
    /// </summary>
    public interface IPostLogService
    {
        /// <summary>
        /// Adds a log of who viewed a post along with the tags associated with it.
        /// </summary>
        /// <param name="model">Post log view model.</param>
        /// <returns>Boolean indicating whether the log entry was saved.</returns>
        Task<bool> AddAsync(PostLogViewModel model);
    }
}