﻿namespace McLintock.Portal.Service.Services
{
    using System;
    using AutoMapper;
    using McLintock.Portal.Core.Interfaces;

    /// <summary>
    /// Base class for services.
    /// </summary>
    public abstract class ServiceBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceBase"/> class.
        /// </summary>
        /// <param name="mapper">IMapper instance.</param>
        /// <param name="securityConfig">Security config instance.</param>
        public ServiceBase(IMapper mapper, ISecurityConfig securityConfig)
        {
            ServiceMapper = mapper ?? throw new ArgumentNullException("mapper");
            SecurityConfig = securityConfig ?? throw new ArgumentNullException("securityConfig");
        }

        /// <summary>
        /// Gets the mapper.
        /// </summary>
        protected IMapper ServiceMapper { get; private set; }

        /// <summary>
        /// Gets the security config.
        /// </summary>
        protected ISecurityConfig SecurityConfig { get; private set; }
    }
}
