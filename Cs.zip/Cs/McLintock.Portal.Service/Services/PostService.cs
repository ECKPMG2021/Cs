﻿namespace McLintock.Portal.Service.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using McLintock.Portal.Core.Extensions;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Repository;

    /// <summary>
    /// Post service.
    /// </summary>
    public class PostService : ServiceBase, IPostService
    {
        private readonly IPostRepository _postRepository;
        private readonly IPostLogRepository _postLogRepository;
        private readonly ITagRepository _tagRepository;
        private readonly IUserGroupRepository _userGroupRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostService"/> class.
        /// </summary>
        /// <param name="mapper">IMapper instance.</param>
        /// <param name="postRepository">Post repository instance.</param>
        /// <param name="postLogRepository">Post log repository instance.</param>
        /// <param name="securityConfig">Security config instance.</param>
        /// <param name="tagRepository">Tag repository instance.</param>
        /// <param name="userGroupRepository">User group repository instance.</param>
        public PostService(
            IMapper mapper,
            IPostRepository postRepository,
            IPostLogRepository postLogRepository,
            ISecurityConfig securityConfig,
            ITagRepository tagRepository,
            IUserGroupRepository userGroupRepository)
            : base(mapper, securityConfig)
        {
            _postRepository = postRepository ?? throw new ArgumentNullException("postRepository");
            _postLogRepository = postLogRepository ?? throw new ArgumentNullException("postLogRepository");
            _tagRepository = tagRepository ?? throw new ArgumentNullException("tagRepository");
            _userGroupRepository = userGroupRepository ?? throw new ArgumentNullException("userGroupRepository");
        }

        /// <summary>
        /// Gets a model to create a new post.
        /// </summary>
        /// <returns>Post view model.</returns>
        public async Task<PostViewModel> CreateAsync()
        {
            var model = new PostViewModel();
            await PopulateListsAsync(model);

            return model;
        }

        /// <summary>
        /// Creates a new post.
        /// </summary>
        /// <param name="model">Post view model.</param>
        /// <returns>Bool indicating whether the post was created.</returns>
        public async Task<bool> CreateAsync(PostViewModel model)
        {
            try
            {
                var entity = ServiceMapper.Map<Post>(model);
                await UpdateListsAsync(model, entity);
                entity.Audit(SecurityConfig.UserId);

                _postRepository.AddOnSubmit(entity);
                await _postRepository.SubmitChangesAsync();
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets a post view model for displaying.
        /// </summary>
        /// <param name="id">The post id.</param>
        /// <returns>Post view model.</returns>
        public async Task<PostViewModel> DetailsAsync(int id)
        {
            var entity = await _postRepository.GetAsync(p => p.Id == id
                && (p.IsPublic
                    || p.CreatedByUserId == SecurityConfig.UserId
                    || p.PostUserGroups.Any(g => g.UserGroup.UserGroupMembers.Any(m =>
                        m.UserId == SecurityConfig.UserId))));

            if (entity != null)
            {
                var model = ServiceMapper.Map<PostViewModel>(entity);
                await PopulateListsAsync(model);
                return model;
            }

            return null;
        }

        /// <summary>
        /// Gets a post view model for editing.
        /// </summary>
        /// <param name="id">The post id.</param>
        /// <returns>Post view model.</returns>
        public async Task<PostViewModel> EditAsync(int id)
        {
            var entity = await _postRepository.GetAsync(p => p.Id == id && p.CreatedByUserId == SecurityConfig.UserId);

            if (entity != null)
            {
                var model = ServiceMapper.Map<PostViewModel>(entity);
                await PopulateListsAsync(model);
                return model;
            }

            return null;
        }

        /// <summary>
        /// Updates an existing post.
        /// </summary>
        /// <param name="model">Post view model.</param>
        /// <returns>Bool indicating whether the post was updated.</returns>
        public async Task<bool> EditAsync(PostViewModel model)
        {
            try
            {
                var entity = await _postRepository.GetAsync(p => p.Id == model.Id
                    && p.CreatedByUserId == SecurityConfig.UserId);

                if (entity == null)
                {
                    return false;
                }

                ServiceMapper.Map(model, entity);
                await UpdateListsAsync(model, entity);
                entity.Audit(SecurityConfig.UserId);

                await _postRepository.SubmitChangesAsync();
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Returns the list of posts the specified user is allowed to view.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of posts.</returns>
        public async Task<List<PostViewModel>> ListAsync(int userId)
        {
            var entities = await _postRepository.GetByUserIdAsync(userId);
            var models = ServiceMapper.Map<List<PostViewModel>>(entities);
            models = models.OrderByDescending(m => m.Created).ToList();

            return models;
        }

        /// <inheritdoc/>
        public async Task<List<PostViewModel>> ListCreatedByUserAsync(int userId)
        {
            var entities = await _postRepository.GetPostsCreatedByUserAsync(userId);
            var models = ServiceMapper.Map<List<PostViewModel>>(entities);
            models = models.OrderByDescending(m => m.Created).ToList();

            return models;
        }

        /// <summary>
        /// Removes the post with the specified Id.
        /// </summary>
        /// <param name="id">Post Id.</param>
        /// <returns>Bool indicating whether the post was removed.</returns>
        public async Task<bool> RemoveAsync(int id)
        {
            try
            {
                var entity = await _postRepository.GetAsync(p => p.Id == id && p.CreatedByUserId == SecurityConfig.UserId);

                if (entity != null)
                {
                    _postRepository.RemoveOnSubmit(entity);
                    await _postRepository.SubmitChangesAsync();
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }

            return true;
        }

        /// <inheritdoc/>
        public async Task<PostSummaryViewModel> SummaryListAsync(int userId, int? authorId, int? tagId)
        {
            var model = new PostSummaryViewModel();
            var allEntities = await _postRepository.GetByUserIdAsync(userId);
            var entities = allEntities.ToList();

            if (authorId.HasValue)
            {
                entities = entities.Where(e => e.CreatedByUserId == authorId).ToList();
            }

            if (tagId.HasValue)
            {
                entities = entities.Where(e => e.PostTags.Any(t => t.TagId == tagId)).ToList();
            }

            var postModels = ServiceMapper.Map<List<PostViewModel>>(entities);
            postModels = postModels.OrderByDescending(m => m.Created).ToList();
            model.Posts = postModels;

            // Select the top authors based on the number of posts created
            model.TopAuthors = allEntities.GroupBy(e => e.CreatedByUser)
                .Select(e => new { e.Key.Id, e.Key.UserName, Posts = e.Count() })
                .Where(e => e.Posts > 0)
                .OrderByDescending(e => e.Posts)
                .Take(5)
                .Select(e =>
                    new LinkViewModel { LinkText = $"{e.UserName} ({e.Posts})", Url = $"/home/index?authorId={e.Id}" })
                .ToList();

            // Select the top posts based on the number of views
            model.TopPosts = (await _postLogRepository.GetPostUsageSummaryAsync(userId))
                .OrderByDescending(p => p.Views)
                .Take(5)
                .Select(e =>
                    new LinkViewModel { LinkText = $"{e.Title} ({e.Views} views)", Url = $"/post/details/{e.Id}" })
                .ToList();

            // Select the tops tags based on the number of views
            model.TopTags = (await _postLogRepository.GetTagUsageSummaryAsync(userId))
                .OrderByDescending(p => p.Views)
                .Take(5)
                .Select(t =>
                    new LinkViewModel { LinkText = $"{t.Name} ({t.Views} views)", Url = $"/home/index/?tagId={t.Id}" })
                .ToList();

            return model;
        }

        private async Task PopulateListsAsync(PostViewModel model)
        {
            await PopulateTagsAsync(model);
            await PopulateUserGroupsAsync(model);
        }

        private async Task PopulateTagsAsync(PostViewModel model)
        {
            var allTags = await _tagRepository.GetAllAsync();

            foreach (var tag in allTags)
            {
                if (!model.Tags.Any(t => t.Id == tag.Id))
                {
                    model.Tags.Add(new ItemSelectViewModel
                    {
                        Id = tag.Id,
                        IsSelected = false,
                        Name = tag.Name,
                    });
                }
            }

            model.Tags = model.Tags.OrderBy(t => t.Name).ToList();
        }

        private async Task PopulateUserGroupsAsync(PostViewModel model)
        {
            var allUserGroups = await _userGroupRepository.GetByUserIdAsync(SecurityConfig.UserId);

            foreach (var userGroup in allUserGroups)
            {
                if (!model.UserGroups.Any(g => g.Id == userGroup.Id))
                {
                    model.UserGroups.Add(new ItemSelectViewModel
                    {
                        Id = userGroup.Id,
                        IsSelected = false,
                        Name = userGroup.Name,
                    });
                }
            }

            model.UserGroups = model.UserGroups.OrderBy(g => g.Name).ToList();
        }

        private async Task UpdateListsAsync(PostViewModel model, Post entity)
        {
            await UpdateTagsAsync(model, entity);
            UpdateUserGroups(model, entity);
        }

        private async Task UpdateTagsAsync(PostViewModel model, Post entity)
        {
            var tags = model.Tags.ToList();

            if (!string.IsNullOrEmpty(model.NewTags))
            {
                model.NewTags.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries).ToList().ForEach(t =>
                {
                    tags.Add(new ItemSelectViewModel { Id = 0, IsSelected = true, Name = t.Trim().Trim('-') });
                });
            }

            foreach (var tagItem in tags)
            {
                if (tagItem.IsSelected && !entity.PostTags.Any(t => t.TagId == tagItem.Id))
                {
                    // If selected and not currently in the post's tag collection,
                    // add the tag to the post
                    var tag = await _tagRepository.GetOrCreateTagAsync(tagItem.Name);
                    entity.PostTags.Add(new PostTag { TagId = tag.Id });
                }
                else if (!tagItem.IsSelected && entity.PostTags.Any(t => t.TagId == tagItem.Id))
                {
                    // If not selected and currently in the post's tag collection,
                    // remove the tag from the post
                    var toRemove = entity.PostTags.Single(t => t.TagId == tagItem.Id);
                    entity.PostTags.Remove(toRemove);
                }
            }
        }

        private void UpdateUserGroups(PostViewModel model, Post entity)
        {
            foreach (var userGroup in model.UserGroups)
            {
                if (userGroup.IsSelected && !entity.PostUserGroups.Any(g => g.UserGroupId == userGroup.Id))
                {
                    // If selected and not currently in the post's user group collection,
                    // add the user group to the post
                    entity.PostUserGroups.Add(new PostUserGroup { UserGroupId = userGroup.Id });
                }
                else if (!userGroup.IsSelected && entity.PostUserGroups.Any(g => g.UserGroupId == userGroup.Id))
                {
                    // If not selected and currently in the post's user group collection,
                    // remove the user group from the post
                    var toRemove = entity.PostUserGroups.Single(g => g.UserGroupId == userGroup.Id);
                    entity.PostUserGroups.Remove(toRemove);
                }
            }
        }
    }
}
