﻿namespace McLintock.Portal.Service.Services
{
    using System;
    using System.Threading.Tasks;
    using AutoMapper;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Repository;

    /// <summary>
    /// Post log service.
    /// </summary>
    public class PostLogService : ServiceBase, IPostLogService
    {
        private readonly IPostLogRepository _postLogRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostLogService"/> class.
        /// </summary>
        /// <param name="mapper">IMapper instance.</param>
        /// <param name="postLogRepository">IPostLogRepository insyance.</param>
        /// <param name="securityConfig">ISecurityConfig instance.</param>
        public PostLogService(
            IMapper mapper,
            IPostLogRepository postLogRepository,
            ISecurityConfig securityConfig)
            : base(mapper, securityConfig)
        {
            _postLogRepository = postLogRepository ?? throw new ArgumentNullException("postLogRepository");
        }

        /// <inheritdoc/>
        public async Task<bool> AddAsync(PostLogViewModel model)
        {
            try
            {
                var entity = ServiceMapper.Map<PostLog>(model);
                entity.UserId = SecurityConfig.UserId;
                await _postLogRepository.AddPostLogAsync(entity);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }
    }
}
