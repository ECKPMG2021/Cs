﻿namespace McLintock.Portal.Service.Services
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Repository;

    /// <summary>
    /// Stats service.
    /// </summary>
    public class StatsService : ServiceBase, IStatsService
    {
        private readonly IPostRepository _postRepository;
        private readonly IPostLogRepository _postLogRepository;
        private readonly ITagRepository _tagRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="StatsService"/> class.
        /// </summary>
        /// <param name="mapper">IMapper instance.</param>
        /// <param name="postRepository">Post repository.</param>
        /// <param name="postLogRepository">Post log repository.</param>
        /// <param name="tagRepository">Tag repository.</param>
        /// <param name="securityConfig">Securit config instance.</param>
        public StatsService(
            IMapper mapper,
            IPostRepository postRepository,
            IPostLogRepository postLogRepository,
            ISecurityConfig securityConfig,
            ITagRepository tagRepository)
            : base(mapper, securityConfig)
        {
            _postRepository = postRepository ?? throw new ArgumentNullException("postRepository");
            _postLogRepository = postLogRepository ?? throw new ArgumentNullException("postLogRepository");
            _tagRepository = tagRepository ?? throw new ArgumentNullException("tagRepository");
        }

        /// <inheritdoc/>
        public async Task<StatsViewModel> GetPostStatsAsync(int id, int days)
        {
            var stats = await _postLogRepository.GetPostStatsAsync(id, SecurityConfig.UserId, days);

            return stats;
        }

        /// <inheritdoc/>
        public async Task<StatsPageViewModel> GetStatsAsync(int days)
        {
            var model = new StatsPageViewModel
            {
                PostSelectListItems = await _postRepository.GetPostSelectListItemsAsync(SecurityConfig.UserId),
                TagSelectListItems = await _tagRepository.GetTagSelectListItemsAsync(SecurityConfig.UserId),
            };

            return model;
        }

        /// <inheritdoc/>
        public async Task<StatsViewModel> GetTagStatsAsync(int id, int days)
        {
            var stats = await _postLogRepository.GetTagStatsAsync(id, SecurityConfig.UserId, days);

            return stats;
        }
    }
}
