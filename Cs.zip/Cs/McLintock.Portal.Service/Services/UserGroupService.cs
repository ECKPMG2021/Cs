﻿namespace McLintock.Portal.Service.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Repository;

    /// <summary>
    /// User group service.
    /// </summary>
    public class UserGroupService : ServiceBase, IService<UserGroupViewModel>
    {
        private readonly IUserGroupRepository _userGroupRepository;
        private readonly IUserRepository _userRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserGroupService"/> class.
        /// </summary>
        /// <param name="mapper">IMapper instance.</param>
        /// <param name="securityConfig">Security config instance.</param>
        /// <param name="userGroupRepository">User group repository instance.</param>
        /// <param name="userRepository">User repository instance.</param>
        public UserGroupService(
            IMapper mapper,
            ISecurityConfig securityConfig,
            IUserGroupRepository userGroupRepository,
            IUserRepository userRepository)
            : base(mapper, securityConfig)
        {
            _userGroupRepository = userGroupRepository ?? throw new ArgumentNullException("userGroupRepository");
            _userRepository = userRepository ?? throw new ArgumentNullException("userRepository");
        }

        /// <summary>
        /// Gets a model to create a new user group.
        /// </summary>
        /// <returns>UserGroupViewModel.</returns>
        public async Task<UserGroupViewModel> CreateAsync()
        {
            var model = new UserGroupViewModel();
            await PopulateUsersAsync(model);

            return model;
        }

        /// <summary>
        /// Creates a new user group.
        /// </summary>
        /// <param name="model">User group view model instance.</param>
        /// <returns>Success status.</returns>
        public async Task<bool> CreateAsync(UserGroupViewModel model)
        {
            if (!ValidateModel(model))
            {
                return false;
            }

            try
            {
                var entity = ServiceMapper.Map<UserGroup>(model);
                entity.UserId = SecurityConfig.UserId;
                UpdateUsers(model, entity);

                _userGroupRepository.AddOnSubmit(entity);
                await _userGroupRepository.SubmitChangesAsync();
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the model to edit a user group.
        /// </summary>
        /// <param name="id">User group Id.</param>
        /// <returns>UserGroupViewModel.</returns>
        public async Task<UserGroupViewModel> EditAsync(int id)
        {
            var entity = await _userGroupRepository.GetAsync(g => g.Id == id && g.UserId == SecurityConfig.UserId);

            if (entity != null)
            {
                var model = ServiceMapper.Map<UserGroupViewModel>(entity);
                await PopulateUsersAsync(model);

                return model;
            }

            return null;
        }

        /// <summary>
        /// Updates an existing user group.
        /// </summary>
        /// <param name="model">User group view model instance.</param>
        /// <returns>Success status.</returns>
        public async Task<bool> EditAsync(UserGroupViewModel model)
        {
            if (!ValidateModel(model))
            {
                return false;
            }

            var entity = await _userGroupRepository.GetAsync(g => g.Id == model.Id
                 && g.UserId == SecurityConfig.UserId);

            if (entity == null)
            {
                return false;
            }

            try
            {
                ServiceMapper.Map(model, entity);
                UpdateUsers(model, entity);
                await _userGroupRepository.SubmitChangesAsync();
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the list of user groups created by the user.
        /// </summary>
        /// <param name="userId">User Id.</param>
        /// <returns>List of user group view models.</returns>
        public async Task<List<UserGroupViewModel>> ListAsync(int userId)
        {
            var entities = await _userGroupRepository.GetByUserIdAsync(userId);
            var models = ServiceMapper.Map<List<UserGroupViewModel>>(entities);

            return models;
        }

        /// <summary>
        /// Removes an existing user group.
        /// </summary>
        /// <param name="id">User group Id.</param>
        /// <returns>Success status.</returns>
        public async Task<bool> RemoveAsync(int id)
        {
            var entity = await _userGroupRepository.GetAsync(g => g.Id == id
                && g.UserId == SecurityConfig.UserId);

            if (entity != null)
            {
                try
                {
                    _userGroupRepository.RemoveOnSubmit(entity);
                    await _userGroupRepository.SubmitChangesAsync();
                }
                catch (Exception)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

            return true;
        }

        private async Task PopulateUsersAsync(UserGroupViewModel model)
        {
            var allUsers = await _userRepository.GetAllUsersAsync();

            foreach (var user in allUsers)
            {
                if (!model.Users.Any(u => u.Id == user.Id))
                {
                    model.Users.Add(new ItemSelectViewModel { Id = user.Id, IsSelected = false, Name = user.UserName });
                }
            }

            model.Users = model.Users.OrderBy(u => u.Name).ToList();
        }

        private void UpdateUsers(UserGroupViewModel model, UserGroup entity)
        {
            foreach (var user in model.Users)
            {
                if (user.IsSelected && !entity.UserGroupMembers.Any(u => u.UserId == user.Id))
                {
                    entity.UserGroupMembers.Add(new UserGroupMember { UserId = user.Id });
                }
                else if (!user.IsSelected && entity.UserGroupMembers.Any(u => u.UserId == user.Id))
                {
                    var member = entity.UserGroupMembers.Single(u => u.UserId == user.Id);
                    entity.UserGroupMembers.Remove(member);
                }
            }
        }

        private bool ValidateModel(UserGroupViewModel model)
        {
            if (string.IsNullOrEmpty(model.Name))
            {
                return false;
            }

            if (!model.Users.Any(u => u.IsSelected))
            {
                return false;
            }

            return true;
        }
    }
}
