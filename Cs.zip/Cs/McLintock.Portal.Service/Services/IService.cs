﻿namespace McLintock.Portal.Service.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Generic service interface.
    /// </summary>
    /// <typeparam name="T">Service model type.</typeparam>
    public interface IService<T>
    {
        Task<T> CreateAsync();

        Task<bool> CreateAsync(T model);

        Task<T> EditAsync(int id);

        Task<bool> EditAsync(T model);

        Task<List<T>> ListAsync(int userId);

        Task<bool> RemoveAsync(int id);
    }
}
