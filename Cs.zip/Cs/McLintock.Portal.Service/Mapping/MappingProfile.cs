﻿namespace McLintock.Portal.Service.Mapping
{
    using System.Linq;
    using AutoMapper;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// Mapping setup.
    /// </summary>
    public class MappingProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MappingProfile"/> class.
        /// </summary>
        public MappingProfile()
        {
            Posts();
            PostLogs();
            UserGroups();
        }

        private void Posts()
        {
            // Entity to model
            CreateMap<Post, PostViewModel>()
                .ForMember(model => model.Created, x => x.MapFrom(entity => entity.Created.ToLocalTime()))
                .ForMember(model => model.CreatedByUserName, x => x.MapFrom(entity => entity.CreatedByUser.UserName))
                .ForMember(model => model.Modified, x => x.MapFrom(entity => entity.Modified.ToLocalTime()))
                .ForMember(model => model.ModifiedByUserName, x => x.MapFrom(entity => entity.ModifiedByUser.UserName))
                .ForMember(
                    model => model.Tags,
                    x => x.MapFrom(entity => entity.PostTags.Select(pt =>
                        new ItemSelectViewModel
                        {
                            Id = pt.TagId,
                            IsSelected = true,
                            Name = pt.Tag.Name,
                        })))
                .ForMember(
                    model => model.UserGroups,
                    x => x.MapFrom(entity => entity.PostUserGroups.Select(ug =>
                        new ItemSelectViewModel
                        {
                            Id = ug.UserGroupId,
                            IsSelected = true,
                            Name = ug.UserGroup.Name,
                        })));

            // Model to entity
            CreateMap<PostViewModel, Post>()
                .ForMember(entity => entity.Created, x => x.Ignore())
                .ForMember(entity => entity.Modified, x => x.Ignore())
                .ForMember(entity => entity.PostTags, x => x.Ignore())
                .ForMember(entity => entity.PostUserGroups, x => x.Ignore());
        }

        private void PostLogs()
        {
            // Entity to model
            CreateMap<PostLog, PostLogViewModel>()
                .ForMember(model => model.AuthorId, x => x.MapFrom(entity => entity.Post.CreatedByUserId))
                .ForMember(model => model.AuthorName, x => x.MapFrom(entity => entity.Post.CreatedByUser.UserName))
                .ForMember(model => model.PostTitle, x => x.MapFrom(entity => entity.Post.Title))
                .ForMember(model => model.Username, x => x.MapFrom(entity => entity.User.UserName))
                .ForMember(model => model.Timestamp, x => x.MapFrom(entity => entity.Timestamp.ToLocalTime()));

            CreateMap<PostLogTag, PostLogTagViewModel>()
                .ForMember(model => model.TagName, x => x.MapFrom(entity => entity.Tag.Name));

            // Model to entity
            CreateMap<PostLogViewModel, PostLog>();

            CreateMap<PostLogTagViewModel, PostLogTag>();
        }

        private void UserGroups()
        {
            // Entity to model
            CreateMap<UserGroup, UserGroupViewModel>()
                .ForMember(
                    model => model.Users,
                    x => x.MapFrom(entity => entity.UserGroupMembers.Select(m =>
                        new ItemSelectViewModel
                        {
                            Id = m.UserId,
                            IsSelected = true,
                            Name = m.User.UserName,
                        })));

            // Model to entity
            CreateMap<UserGroupViewModel, UserGroup>()
                .ForMember(entity => entity.UserId, x => x.Ignore());
        }
    }
}
