﻿namespace McLintock.Portal.TestHelpers
{
    using System;
    using McLintock.Portal.Data.Entity;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// In memory database helper.
    /// </summary>
    public static class InMemoryDb
    {
        /// <summary>
        /// Gets an instance of the db context.
        /// </summary>
        /// <returns>McLintockPortalContext.</returns>
        public static McLintockPortalContext GetMcLintockPortalContext()
        {
            var builder = new DbContextOptionsBuilder<McLintockPortalContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString());

            return new McLintockPortalContext(builder.Options);
        }
    }
}
