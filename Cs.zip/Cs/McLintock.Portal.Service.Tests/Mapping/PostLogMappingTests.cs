﻿namespace McLintock.Portal.Service.Tests.Mapping
{
    using System;
    using System.Collections.Generic;
    using AutoMapper;
    using FluentAssertions;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Service.Mapping;
    using Xunit;

    /// <summary>
    /// Post log mapping tests.
    /// </summary>
    public class PostLogMappingTests
    {
        private static IMapper mapper;

        /// <summary>
        /// Gets mapper instance.
        /// </summary>
        protected static IMapper Mapper
        {
            get
            {
                if (mapper == null)
                {
                    var mapperCfg = new MapperConfiguration(cfg => cfg.AddProfile(new MappingProfile()));
                    mapper = mapperCfg.CreateMapper();
                }

                return mapper;
            }
        }

        [Fact]
        private void PostLogMapping_EntityMapsToModelCorrectly()
        {
            // Arrange
            var entity = new PostLog
            {
                Id = 1,
                Post = new Post
                {
                    CreatedByUser = new ApplicationIdentityUser { Id = 1, UserName = "U1" },
                    CreatedByUserId = 1,
                    Id = 1,
                    Title = "Post1",
                },
                PostId = 1,
                Tags = new List<PostLogTag>
              {
                  new PostLogTag
                  {
                      Id = 1,
                      Tag = new Tag
                      {
                          Id = 1,
                          Name = "T1",
                      },
                      TagId = 1,
                  },
                  new PostLogTag
                  {
                      Id = 2,
                      Tag = new Tag
                      {
                          Id = 2,
                          Name = "T2",
                      },
                      TagId = 2,
                  },
              },
                Timestamp = new DateTime(2000, 1, 1),
                User = new ApplicationIdentityUser { Id = 2, UserName = "U2" },
                UserId = 2,
            };

            // Act
            var model = Mapper.Map<PostLogViewModel>(entity);

            // Assert
            model.Should().NotBeNull();
            model.AuthorId.Should().Be(1);
            model.AuthorName.Should().Be("U1");
            model.PostId.Should().Be(1);
            model.PostTitle.Should().Be("Post1");
            model.Tags.Should().HaveCount(2)
                .And.SatisfyRespectively(
                t1 =>
                {
                    t1.TagId.Should().Be(1);
                    t1.TagName.Should().Be("T1");
                },
                t2 =>
                {
                    t2.TagId.Should().Be(2);
                    t2.TagName.Should().Be("T2");
                });
            model.Timestamp.Should().Be(new DateTime(2000, 1, 1, 0, 0, 0, DateTimeKind.Utc).ToLocalTime());
            model.UserId.Should().Be(2);
            model.Username.Should().Be("U2");
        }
    }
}
