﻿namespace McLintock.Portal.Service.Tests.Services
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using FluentAssertions;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.Service.Services;
    using Xunit;

    /// <summary>
    /// Post log service tests.
    /// </summary>
    public class PostLogServiceTests : ServiceTestBase
    {
        private IPostLogService _postLogService;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostLogServiceTests"/> class.
        /// </summary>
        public PostLogServiceTests()
        {
            GetContext();

            var postLogRepository = new PostLogRepository(Context);

            _postLogService = new PostLogService(
                ServiceMapper,
                postLogRepository,
                SecurityConfig.Object);
        }

        /// <summary>
        /// Test the post logging functionality.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task PostLogService_AddAsync_SucceedsWithValidModel()
        {
            // Arrange
            Context.Posts.Add(new Post
            {
                Content = "P1 Content",
                Created = DateTime.UtcNow,
                CreatedByUser = new ApplicationIdentityUser
                {
                    Email = "1@mail.com",
                    Id = 1,
                    UserName = "U1",
                },
                Id = 1,
                IsPublic = true,
                Modified = DateTime.UtcNow,
                ModifiedByUserId = 1,
                PostTags = new List<PostTag>
                {
                    new PostTag { Tag = new Tag { Name = "T1" } },
                    new PostTag { Tag = new Tag { Name = "T2" } },
                },
            });
            Context.SaveChanges();

            var logModel = new PostLogViewModel
            {
                PostId = 1,
                Tags = new List<PostLogTagViewModel>
                {
                    new PostLogTagViewModel { TagId = 1, },
                    new PostLogTagViewModel { TagId = 2, },
                },
            };

            SecurityConfig.Setup(s => s.UserId).Returns(2);

            // Act
            var result = await _postLogService.AddAsync(logModel);

            // Assert
            result.Should().Be(true);
            Context.PostLogs.Should().HaveCount(1)
                .And.SatisfyRespectively(
                l1 =>
                {
                    l1.PostId.Should().Be(1);
                    l1.UserId.Should().Be(2);
                });
            Context.PostLogTags.Should().HaveCount(2);
        }
    }
}
