﻿namespace McLintock.Portal.Service.Tests.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using FluentAssertions;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.Service.Services;
    using Xunit;

    /// <summary>
    /// User group service.
    /// </summary>
    public class UserGroupServiceTests : ServiceTestBase
    {
        private IService<UserGroupViewModel> _userGroupService;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserGroupServiceTests"/> class.
        /// </summary>
        public UserGroupServiceTests()
        {
            GetContext();

            var userGroupRepository = new UserGroupRepository(Context);
            var userRepository = new UserRepository(Context);

            _userGroupService = new UserGroupService(
                ServiceMapper,
                SecurityConfig.Object,
                userGroupRepository,
                userRepository);
        }

        /// <summary>
        /// Test that the correct user groups are returned for each user.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task UserGroupService_List_ReturnsCorrectUserGroups()
        {
            // Arrange
            Context.UserGroups.AddRange(new List<UserGroup>
            {
                new UserGroup { Id = 1, Name = "UG1", UserId = 1 },
                new UserGroup { Id = 2, Name = "UG2", UserId = 2 },
            });
            Context.SaveChanges();

            // Act
            var result = await _userGroupService.ListAsync(1);

            // Assert
            result.Should().NotBeEmpty("there should be 1 user group returned.")
                .And.HaveCount(1, "there should only be the user group associated with the specified user returned")
                .And.SatisfyRespectively(
                    group1 =>
                    {
                        group1.Name.Should().Be("UG1");
                    });
        }

        [Fact]
        public async Task UserGroupService_Create_ReturnsCorrectModel()
        {
            // Arrange
            Context.Users.AddRange(new List<ApplicationIdentityUser>
            {
                new ApplicationIdentityUser { Id = 1, Email = "1@mail.com", UserName = "1" },
                new ApplicationIdentityUser { Id = 2, Email = "2@mail.com", UserName = "2" },
            });
            Context.SaveChanges();

            // Act
            var model = await _userGroupService.CreateAsync();

            // Assert
            model.Should().NotBeNull();
            model.Name.Should().BeNullOrEmpty();
            model.Users.Should().NotBeEmpty()
                .And.HaveCount(2)
                .And.Match<List<ItemSelectViewModel>>(m => m.TrueForAll(i => i.IsSelected == false));
        }

        [Fact]
        public async Task UserGroupService_Create_SucceedsWithValidModel()
        {
            // Arrange
            Context.Users.AddRange(new List<ApplicationIdentityUser>
            {
                new ApplicationIdentityUser { Id = 1, Email = "1@mail.com", UserName = "1" },
                new ApplicationIdentityUser { Id = 2, Email = "2@mail.com", UserName = "2" },
            });
            Context.SaveChanges();

            var model = await _userGroupService.CreateAsync();

            // Act
            model.Name = "UG1";
            model.Users.First().IsSelected = true;
            var result = await _userGroupService.CreateAsync(model);

            // Assert
            result.Should().BeTrue();
            Context.UserGroups.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(group1 =>
                {
                    group1.Id.Should().Be(1);
                    group1.Name.Should().Be("UG1");
                    group1.UserId.Should().Be(1);
                });
            Context.UserGroupMembers.Should()
                .HaveCount(1, "only 1 user was selected to be added to the group.")
                .And.SatisfyRespectively(groupMember1 =>
                {
                    groupMember1.UserGroupId.Should().Be(1);
                    groupMember1.UserId.Should().Be(1);
                });
        }

        [Fact]
        public async Task UserGroupService_Create_FailsWithNoUsersSelected()
        {
            // Arrange
            Context.Users.AddRange(new List<ApplicationIdentityUser>
            {
                new ApplicationIdentityUser { Id = 1, Email = "1@mail.com", UserName = "1" },
                new ApplicationIdentityUser { Id = 2, Email = "2@mail.com", UserName = "2" },
            });
            Context.SaveChanges();

            var model = await _userGroupService.CreateAsync();

            // Act
            model.Name = "UG1";
            var result = await _userGroupService.CreateAsync(model);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UserGroupService_Create_FailsWithNoName()
        {
            // Arrange
            Context.Users.AddRange(new List<ApplicationIdentityUser>
            {
                new ApplicationIdentityUser { Id = 1, Email = "1@mail.com", UserName = "1" },
                new ApplicationIdentityUser { Id = 2, Email = "2@mail.com", UserName = "2" },
            });
            Context.SaveChanges();

            var model = await _userGroupService.CreateAsync();

            // Act
            model.Users.First().IsSelected = true;
            var result = await _userGroupService.CreateAsync(model);

            // Assert
            result.Should().BeFalse();
        }

        [Fact]
        public async Task UserGroupService_Edit_ReturnsCorrectModel()
        {
            // Arrange
            Context.UserGroups.Add(new UserGroup
            {
                Id = 1,
                Name = "UG1",
                User = new ApplicationIdentityUser { Id = 1, UserName = "1", Email = "1@mail.com" },
                UserGroupMembers = new List<UserGroupMember>
                {
                    new UserGroupMember { User = new ApplicationIdentityUser { Id = 2, UserName = "2", Email = "2@mail.com" } },
                },
            });
            Context.SaveChanges();

            // Act
            var model = await _userGroupService.EditAsync(1);

            // Assert
            model.Should().NotBeNull();
            model.Name.Should().Be("UG1");
            model.Users.Should().HaveCount(2, "2 users should have been created in the setup.")
                .And.SatisfyRespectively(
                user1 =>
                {
                    user1.IsSelected.Should().BeFalse();
                },
                user2 =>
                {
                    user2.IsSelected.Should().BeTrue();
                    user2.Name.Should().Be("2");
                });
        }

        [Fact]
        public async Task UserGroupService_Edit_SucceedsWithValidModel()
        {
            // Arrange
            Context.UserGroups.Add(new UserGroup
            {
                Id = 1,
                Name = "UG1",
                User = new ApplicationIdentityUser { Id = 1, UserName = "1", Email = "1@mail.com" },
                UserGroupMembers = new List<UserGroupMember>
                {
                    new UserGroupMember { User = new ApplicationIdentityUser { Id = 2, UserName = "2", Email = "2@mail.com" } },
                },
            });
            Context.SaveChanges();
            var model = await _userGroupService.EditAsync(1);

            // Act
            model.Name = "Edited";
            model.Users.First().IsSelected = true;
            model.Users.Last().IsSelected = false;
            var result = await _userGroupService.EditAsync(model);

            // Assert
            result.Should().BeTrue();
            Context.UserGroups.First().Name.Should().Be("Edited");
            Context.UserGroups.First().UserId.Should().Be(1);
            Context.UserGroupMembers.Should().HaveCount(1)
                .And.SatisfyRespectively(
                member1 =>
                {
                    member1.UserId.Should().Be(1);
                    member1.UserGroupId.Should().Be(1);
                });
        }
    }
}
