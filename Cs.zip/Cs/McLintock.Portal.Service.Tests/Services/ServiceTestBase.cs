﻿namespace McLintock.Portal.Service.Tests.Services
{
    using AutoMapper;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Service.Mapping;
    using McLintock.Portal.TestHelpers;
    using Moq;

    /// <summary>
    /// Service test base class.
    /// </summary>
    public abstract class ServiceTestBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceTestBase"/> class.
        /// </summary>
        public ServiceTestBase()
        {
            var mapperCfg = new MapperConfiguration(cfg => cfg.AddProfile(new MappingProfile()));
            ServiceMapper = mapperCfg.CreateMapper();

            SecurityConfig = new Mock<ISecurityConfig>();
            SecurityConfig.Setup(s => s.UserId).Returns(1);
        }

        /// <summary>
        /// Gets a fresh in memory db to test against.
        /// </summary>
        protected void GetContext()
        {
            Context = InMemoryDb.GetMcLintockPortalContext();
        }

        /// <summary>
        /// Gets the mapper.
        /// </summary>
        protected IMapper ServiceMapper { get; }

        /// <summary>
        /// Gets the db context.
        /// </summary>
        protected McLintockPortalContext Context { get; private set; }

        /// <summary>
        /// Gets the security config mock.
        /// </summary>
        protected Mock<ISecurityConfig> SecurityConfig { get; }
    }
}
