﻿namespace McLintock.Portal.Service.Tests.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using FluentAssertions;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.Service.Mapping;
    using McLintock.Portal.Service.Services;
    using McLintock.Portal.TestHelpers;
    using Moq;
    using Xunit;

    /// <summary>
    /// Post service tests.
    /// </summary>
    [Collection("PostServiceTests")]
    public class PostServiceTests
    {
        private McLintockPortalContext _context;
        private IService<PostViewModel> _postService;

        /// <summary>
        /// Initializes a new instance of the <see cref="PostServiceTests"/> class.
        /// </summary>
        public PostServiceTests()
        {
            _context?.Dispose();

            var mapperCfg = new MapperConfiguration(cfg => cfg.AddProfile(new MappingProfile()));
            IMapper mapper = mapperCfg.CreateMapper();

            var securityConfig = new Mock<ISecurityConfig>();
            securityConfig.Setup(s => s.UserId).Returns(1);

            _context = InMemoryDb.GetMcLintockPortalContext();

            var postRepository = new PostRepository(_context);
            var postLogRepository = new PostLogRepository(_context);
            var tagRepository = new TagRepository(_context);
            var userGroupRepository = new UserGroupRepository(_context);

            _postService = new PostService(
                mapper,
                postRepository,
                postLogRepository,
                securityConfig.Object,
                tagRepository,
                userGroupRepository);
        }

        /// <summary>
        /// Verifies the model that is returned to create a new post.
        /// </summary>
        [Fact]
        public async Task PostService_Create_ReturnsCorrectModel()
        {
            // Arrange
            _context.Tags.Add(new Tag { Id = 1, Name = "T1" });

            _context.UserGroups.AddRange(new List<UserGroup>
            {
                new UserGroup { Id = 1, Name = "G1", UserId = 1 },
                new UserGroup { Id = 2, Name = "G2", UserId = 2 },
            });

            _context.SaveChanges();

            // Act
            var model = await _postService.CreateAsync();

            // Assert
            model.Should().NotBeNull();

            model.Tags.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(
                tag1 =>
                {
                    tag1.IsSelected.Should().BeFalse();
                });

            model.UserGroups.Should().NotBeEmpty()
                .And.HaveCount(1, "it should only display groups associated with the current user.")
                .And.SatisfyRespectively(
                group1 =>
                {
                    group1.Name.Should().Be("G1");
                    group1.IsSelected.Should().BeFalse();
                });
        }

        /// <summary>
        /// Verifies the creation of a basic post with no security and no tags.
        /// </summary>
        [Fact]
        public async Task PostService_Create_AddValidModelWithNoTagsOrUserGroups()
        {
            // Arrange
            var model = await _postService.CreateAsync();
            model.Title = "Post1";
            model.Content = "Post1 Content";
            model.IsPublic = true;

            // Act
            var result = await _postService.CreateAsync(model);

            // Assert
            result.Should().BeTrue();
            _context.Posts.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(
                post1 =>
                {
                    post1.Content.Should().Be("Post1 Content");
                    post1.CreatedByUserId.Should().Be(1);
                    post1.ModifiedByUserId.Should().Be(1);
                    post1.Title.Should().Be("Post1");
                });
        }

        /// <summary>
        /// Verifies the creation of a basic post with security.
        /// </summary>
        [Fact]
        public async Task PostService_Create_AddValidModelWithSecurity()
        {
            // Arrange
            _context.UserGroups.Add(new UserGroup
            {
                Id = 1,
                Name = "UG1",
                UserId = 1,
                UserGroupMembers = new List<UserGroupMember> { new UserGroupMember { UserId = 1 } },
            });
            _context.SaveChanges();

            var model = await _postService.CreateAsync();
            model.Title = "Post1";
            model.Content = "Post1 Content";
            model.IsPublic = false;
            model.UserGroups.First().IsSelected = true;

            // Act
            var result = await _postService.CreateAsync(model);

            // Assert
            result.Should().BeTrue();
            _context.Posts.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(
                post1 =>
                {
                    post1.Content.Should().Be("Post1 Content");
                    post1.CreatedByUserId.Should().Be(1);
                    post1.ModifiedByUserId.Should().Be(1);
                    post1.Title.Should().Be("Post1");
                });
            _context.PostUserGroups.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(
                postUserGroup =>
                {
                    postUserGroup.PostId = 1;
                    postUserGroup.UserGroupId = 1;
                });
        }

        /// <summary>
        /// Verifies the creation of a basic post with tags.
        /// </summary>
        [Fact]
        public async Task PostService_Create_AddValidModelWithTags()
        {
            // Arrange
            _context.Tags.Add(new Tag { Id = 1, Name = "T1" });
            _context.SaveChanges();

            var model = await _postService.CreateAsync();
            model.Title = "Post1";
            model.Content = "Post1 Content";
            model.Id = 1;
            model.IsPublic = true;
            model.Tags.First().IsSelected = true;
            model.NewTags = "T2";

            // Act
            var result = await _postService.CreateAsync(model);

            // Assert
            result.Should().BeTrue();
            _context.Posts.Should().NotBeEmpty()
                .And.HaveCount(1)
                .And.SatisfyRespectively(
                post1 =>
                {
                    post1.Content.Should().Be("Post1 Content");
                    post1.CreatedByUserId.Should().Be(1);
                    post1.ModifiedByUserId.Should().Be(1);
                    post1.Title.Should().Be("Post1");
                });
            _context.PostTags.Should().NotBeEmpty()
                .And.HaveCount(2)
                .And.SatisfyRespectively(
                postTag1 =>
                {
                    postTag1.PostId.Should().Be(1);
                    postTag1.Tag.Name.Should().Be("T1");
                },
                postTag2 =>
                {
                    postTag2.PostId.Should().Be(1);
                    postTag2.Tag.Name.Should().Be("T2");
                });
            _context.Tags.Should().NotBeEmpty()
                .And.HaveCount(2)
                .And.SatisfyRespectively(
                tag1 =>
                {
                    tag1.Name.Should().Be("T1");
                },
                tag2 =>
                {
                    tag2.Name.Should().Be("T2");
                });
        }

        [Fact]
        public async Task PostService_Edit_ReturnsCorrectModel()
        {
            // Arrange
            _context.Posts.Add(new Post
            {
                Content = "Post content",
                CreatedByUser = new ApplicationIdentityUser
                {
                    Email = "1@mail.com",
                    Id = 1,
                    UserName = "user1",
                },
                Id = 1,
                IsPublic = false,
                ModifiedByUserId = 1,
                PostTags = new List<PostTag>
                {
                    new PostTag { Tag = new Tag { Name = "T1" } },
                },
                PostUserGroups = new List<PostUserGroup>
                {
                    new PostUserGroup { UserGroup = new UserGroup { Name = "UG1", UserId = 1 } },
                },
                Title = "Post1",
            });
            _context.Tags.Add(new Tag { Name = "T2" });
            _context.UserGroups.Add(new UserGroup { Name = "UG2", UserId = 1 });
            _context.SaveChanges();

            // Act
            var model = await _postService.EditAsync(1);

            // Assert
            model.Should().NotBeNull();
            model.Content.Should().Be("Post content");
            model.CreatedByUserName.Should().Be("user1");
            model.Tags.Should().HaveCount(2)
                .And.SatisfyRespectively(
                t1 =>
                {
                    t1.IsSelected.Should().Be(true);
                    t1.Name.Should().Be("T1");
                },
                t2 =>
                {
                    t2.IsSelected.Should().Be(false);
                    t2.Name.Should().Be("T2");
                });
            model.UserGroups.Should().HaveCount(2)
                .And.SatisfyRespectively(
                g1 =>
                {
                    g1.IsSelected.Should().Be(true);
                    g1.Name.Should().Be("UG1");
                },
                g2 =>
                {
                    g2.IsSelected.Should().Be(false);
                    g2.Name.Should().Be("UG2");
                });
        }

        /// <summary>
        /// Test that the post remove function works and removes any orphaned entities.
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task PostService_Remove_SucceedsAndRemovesChildEntities()
        {
            // Arrange
            _context.Posts.Add(new Post
            {
                Content = "Post content",
                CreatedByUser = new ApplicationIdentityUser
                {
                    Id = 1,
                    Email = "1@mail.com",
                    UserName = "U1",
                },
                Id = 1,
                IsPublic = false,
                ModifiedByUserId = 1,
                PostTags = new List<PostTag> { new PostTag { Tag = new Tag { Id = 1, Name = "T1" } } },
                PostUserGroups = new List<PostUserGroup>
                {
                    new PostUserGroup
                    {
                        UserGroup = new UserGroup
                        {
                            Id = 1,
                            Name = "UG1",
                            User = new ApplicationIdentityUser
                            {
                                 Id = 1,
                                 Email = "1@mail.com",
                                 UserName = "U1",
                            },
                        },
                    },
                },
                Title = "Post1",
            });

            _context.SaveChanges();

            // Confirm that the required entities are in place
            _context.Posts.Should().HaveCount(1);
            _context.PostTags.Should().HaveCount(1);
            _context.PostUserGroups.Should().HaveCount(1);
            _context.Tags.Should().HaveCount(1);
            _context.UserGroups.Should().HaveCount(1);
            _context.Users.Should().HaveCount(1);

            // Act
            var result = await _postService.RemoveAsync(1);

            // Assert
            result.Should().BeTrue();
            _context.Posts.Should().HaveCount(0);
            _context.PostTags.Should().HaveCount(0);
            _context.PostUserGroups.Should().HaveCount(0);
            _context.Tags.Should().HaveCount(1, "the tag join table entry should be removed but the tag should remain.");
            _context.UserGroups.Should().HaveCount(1, "the post group join table entry should be removed but the group should remain.");
            _context.Users.Should().HaveCount(1, "the users should not be affected by the post removal.");
        }
    }
}
