﻿// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given
// a specific target and scoped to a namespace, type, member, etc.
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1101:Prefix local calls with this", Justification = "Not required", Scope = "NamespaceAndDescendants", Target = "McLintock.Portal.Service.Tests")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.NamingRules", "SA1309:Field names should not begin with underscore", Justification = "NotRequired", Scope = "NamespaceAndDescendants", Target = "McLintock.Portal.Service.Tests")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1616:Element return value documentation should have text", Justification = "Not required", Scope = "NamespaceAndDescendants", Target = "McLintock.Portal.Service.Tests")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1615:Element return value should be documented", Justification = "Not required", Scope = "NamespaceAndDescendants", Target = "McLintock.Portal.Service.Tests")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "xUnit1013:Public method should be marked as test", Justification = "Not required on the dispose method", Scope = "member", Target = "~M:McLintock.Portal.Service.Tests.Services.PostServiceTests.Dispose")]
