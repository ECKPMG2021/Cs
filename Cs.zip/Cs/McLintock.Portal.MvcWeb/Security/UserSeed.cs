﻿namespace McLintock.Portal.MvcWeb.Security
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using Microsoft.AspNetCore.Identity;

    /// <summary>
    /// User seed utility class.
    /// </summary>
    public static class UserSeed
    {
        private static string[] users = new string[]
        {
            "wm",
            "brendanbrazier",
            "mattdanzig",
            "deanhowell",
            "robertcheeke",
            "frankmedrano",
            "zakcovalcik",
            "joshgarrett",
            "emilyjans",
            "christinevarderos",
            "ruthheidrich",
        };


        /// <summary>
        /// Add fake users to the db.
        /// </summary>
        /// <param name="userManager">UserManager.<ApplicationIdentityUser> instance.</param>
        /// <param name="context">McLintockPortalContext instance.</param>
        /// <returns>Success status.</returns>
        public static async Task<bool> GenerateUsersAsync(
            UserManager<ApplicationIdentityUser> userManager,
            McLintockPortalContext context)
        {
            if (context.Users.Any())
            {
                return true;
            }

            try
            {
                foreach (var user in users)
                {
                    var username = $"{user}@mclintock.co.uk";
                    var appUser = new ApplicationIdentityUser { Email = username, UserName = username, };
                    await userManager.CreateAsync(appUser, "P@ssw0rd");
                }

                foreach (var user in context.Users)
                {
                    user.EmailConfirmed = true;
                }

                await context.SaveChangesAsync();
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }
    }
}
