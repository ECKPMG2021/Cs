﻿namespace McLintock.Portal.MvcWeb.Security
{
    using System;
    using System.Security.Claims;
    using McLintock.Portal.Core.Interfaces;
    using Microsoft.AspNetCore.Http;

    /// <summary>
    /// Mvc Web Security Config.
    /// </summary>
    public class MvcWebSecurityConfig : ISecurityConfig
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Initializes a new instance of the <see cref="MvcWebSecurityConfig"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">IHttpContextAccessor instance.</param>
        public MvcWebSecurityConfig(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException("httpContextAccessor");
        }

        /// <inheritdoc/>
        public int UserId
        {
            get => Convert.ToInt32(_httpContextAccessor.HttpContext.User.FindFirst(ClaimTypes.NameIdentifier).Value);
            set => throw new NotImplementedException();
        }
    }
}
