﻿var color = Chart.helpers.color;
var colorNames = Object.keys(window.chartColors);
var durationInDays = [10, 20, 30, 40, 50];

// Maximize chart
function Maximize(divToMaximize) {
    $("#" + divToMaximize).removeClass('chart-container').addClass('chart-container-maximized');
    $("#svgMax" + divToMaximize).removeClass('d-block').addClass('d-none');
    $("#svgMin" + divToMaximize).removeClass('d-none').addClass('d-block');

}

// Mainimize chart
function Minimize(divToMaximize) {
    $("#" + divToMaximize).removeClass('chart-container-maximized').addClass('chart-container');
    $("#svgMin" + divToMaximize).removeClass('d-block').addClass('d-none');
    $("#svgMax" + divToMaximize).removeClass('d-none').addClass('d-block');
}


// Calls API to get chart Data and on success call BindStats method to draw chart
function GetChartData(chartCanvas, params) {
    $.ajax({
        type: "GET",
        url: "Stats/" + params,
        contentType: "application/json",
        dataType: "json",
        success: function (response) {
            //debugger;
            //console.log(response);
            BindStats(chartCanvas, response)
        },
        error: function () {
            alert("Error in Stats service.");
        }
    });

}

function BindStats(chartCanvas, chartData) {
    if (chartCanvas === "canvasPostsChart")
        BuildPostsChart(chartData);
    if (chartCanvas === "canvasTagsChart")
        BuildTagsChart(chartData);
}



function BuildPostsChart(chartData) {

    // Prepare chart axis data
    var XaxisLabels = chartData.userstats.map(function (e) {
        return e.x;
    });
    var YaxisUsersData = chartData.userstats.map(function (e) {
        return e.y;
    });
    var YaxisViewsData = chartData.userstats.map(function (e) {
        return e.y;
    });


    var canvas = document.getElementById("canvasPostsChart");
    var ctx = canvas.getContext('2d');

    // Prepare chart dataset
    var postsChartData = {
        labels: XaxisLabels,
        datasets: [{
            label: 'Users',
            backgroundColor: "#ffff00",
            borderColor: "#ffff00",
            borderWidth: 1,
            data: YaxisUsersData
        },
        {
            label: 'Views',
            backgroundColor: "#0000ff",
            borderColor: "#0000ff",
            borderWidth: 1,
            data: YaxisViewsData
        }
        ]

    };

    console.log(window.postsChart);
    if (typeof window.postsChart === 'object' && window.postsChart !== null) {

        window.postsChart.destroy();
    }
    // Create Chart
    window.postsChart = new Chart(ctx, {
        type: 'bar',
        data: postsChartData,
        options: {
            responsive: true,
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Post Stats'
            },
            scales: {
                xAxes: [{
                    ticks: {
                        autoSkip: false,
                        maxRotation: 90,
                        minRotation: 90
                    }
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        stepSize: 1,
                    }
                }]

            }
        }
    });
    canvasPostsChart.update();

}

function BuildTagsChart(chartData) {
    // Prepare chart axis data
    var XaxisLabels = chartData.userstats.map(function (e) {
        return e.x;
    });
    var YaxisUsersData = chartData.userstats.map(function (e) {
        return e.y;
    });
    var YaxisViewsData = chartData.userstats.map(function (e) {
        return e.y;
    });
    var canvas = document.getElementById("canvasTagsChart");
    var ctx = canvas.getContext('2d');

    // Prepare chart dataset
    var tagsChartData = {
        labels: XaxisLabels,
        datasets: [{
            label: 'Users',
            backgroundColor: "#ff0000",
            borderColor: "#ff0000",
            borderWidth: 1,
            data: YaxisUsersData
        },
        {
            label: 'Views',
            backgroundColor: "#33cc33",
            borderColor: "#33cc33",
            borderWidth: 1,
            data: YaxisViewsData
        }
        ]

    };

    console.log(window.tagsChart);
    if (typeof window.tagsChart === 'object' && window.tagsChart !== null) {
        window.tagsChart.destroy();
    }

    // Create Chart
    window.tagsChart = new Chart(ctx, {
        type: 'bar',
        data: tagsChartData,
        options: {
            responsive: true,

            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Tags Stats'
            },
            scales: {
                xAxes: [{
                    ticks: {
                        autoSkip: false,
                        maxRotation: 90,
                        minRotation: 90
                    }
                }],
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        stepSize: 1,
                    }
                }]

            }
        }
    });
    tagsChart.update();

}