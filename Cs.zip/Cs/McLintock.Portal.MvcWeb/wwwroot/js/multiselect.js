﻿; (function ($) {

    var methods = {
        init: function (options) {
        }
    };

    $.fn.multiSelect = function (options) {

        var settings = $.extend({
            'selectText': 'Type here to select',
            'width': '100%'
        }, options);

        var defaults = {
            // Attributes
            clsContainer: 'mss-container',
            clsSearch: 'mss-search',
            clsResults: 'mss-results',
            clsItems: 'mss-items',
            clsDefault: 'mss-default',
            clsSelected: 'mss-selected',
            clsHighlighted: 'mss-highlighted',
            clsDisabled: 'mss-disabled',
            clsRemove: 'mss-remove',
            clsNoMatch: 'mss-no-match',
            clsExclude: 'mss-exclude'
        };

        // Clears the current search results
        var clearSearch = function (search, results) {
            if (search.is(':focus')) {
                search.val(null);
                search.removeClass(defaults.clsDefault);
                search.removeClass(defaults.clsNoMatch);
            }
            else {
                search.val(settings.selectText);
                search.addClass(defaults.clsDefault);
            }

            results.data('search', null);
        };

        // Sets the selection status on an item
        var setItemSelected = function (row, isSelected) {
            var selectedInput = $('input.' + defaults.clsSelected, row);

            if (isSelected) {
                selectedInput.val('True');
                row.show();
            }
            else {
                selectedInput.val('False');
                row.hide();
            }
        };

        // Sets the disabled status on an item
        var setItemDisabled = function (row, isDisabled) {
            var disabledInput = $('input.' + defaults.clsDisabled, row);

            if (isSelected) {
                disabledInput.val('True');
                row.addClass(desults.clsDisabled);
            }
            else {
                disabledInput.val('False');
                row.addClass(desults.clsDisabled);
            }
        };

        // Selects a result row
        var selectResult = function (resultRow) {
            // Configure result row
            resultRow.addClass(defaults.clsSelected);
            resultRow.hide();

            // Select the item
            setItemSelected($(resultRow.data('item')), true);
        };

        // Creates a table of results for searching
        var initialiseResults = function (search, results, items) {
            // Set flag to indicate if the results should stay visible
            results.data('stay-open', false);

            // Required as IE and Chrome blur on the search control when the
            // scrollbar of the results is clicked
            results.mousedown(function (e) {
                results.data('stay-open', search.is(':focus'));
            });

            // Create new result table
            var resultTable = $('<table><tbody></tbody></table>');

            $('tbody tr', items).each(function () {
                var currentRow = $(this);
                var resultRow = $('<tr></tr>').data('item', '#' + currentRow.attr('id'));

                // Create columns for current row
                $('td', currentRow).not('.exclude').each(function () {
                    var columText = $(this).text();
                    resultRow.append($('<td></td>').text(columText));
                });

                // Add to master result table
                $('tbody', resultTable).append(resultRow);

                // Bind events
                resultRow.mousemove(function () {
                    // Ensure no other rows are highlighted
                    $('tr.' + defaults.clsHighlighted, resultTable).each(function () {
                        $(this).removeClass(defaults.clsHighlighted);
                    });

                    // Highlight the current row
                    resultRow.addClass(defaults.clsHighlighted);
                });

                resultRow.mouseout(function () {
                    // Ensure the row is no longer highlighted
                    resultRow.removeClass(defaults.clsHighlighted);
                });

                resultRow.mousedown(function () {
                    // Select the result
                    selectResult(resultRow);

                    // Clear flag
                    results.data('stay-open', false);

                    // Clear search
                    clearSearch(search, results);
                    search.blur();
                });

                // Determine if the result is already selected
                if ($('input.' + defaults.clsSelected, currentRow).val() === 'True') {
                    selectResult(resultRow);
                }
                if ($('input.' + defaults.clsDisabled, currentRow).val() === 'True') {
                    currentRow.addClass(defaults.clsDisabled);
                }

                // Configure remove action
                $('a.' + defaults.clsRemove, currentRow).click(function () {

                    setItemSelected(currentRow, false);
                    resultRow.removeClass(defaults.clsSelected);
                });
            });

            results.html(resultTable);
        };

        var showResults = function (results) {
            if (!results.is(':visible')) {
                results.show();
                results.scrollTop(0);
            }
        };

        // Performs a search on the items
        var performSearch = function (search, results, items) {
            // Get the current search expression
            var searchExpression = search.val().toLowerCase();

            // Only search when the search expression has changed or is empty
            if (results.data('search') !== searchExpression || searchExpression.length === 0 || !results.is(':visible')) {
                var matchCount = 0;

                $('tbody tr:not(.' + defaults.clsSelected + ')', results).each(function () {
                    var match = false;
                    var currentRow = $(this);

                    // Determine if any cells match the search expression
                    $('td', currentRow).each(function () {
                        if ($(this).text().toLowerCase().indexOf(searchExpression) !== -1) {
                            match = true;
                            matchCount++;

                            // Stop checking cells on the current row
                            return false;
                        }
                    });

                    // Show/hide row if it matches
                    if (match)
                        currentRow.show();
                    else {
                        currentRow.hide();
                        currentRow.removeClass(defaults.clsHighlighted);
                    }
                });

                // Show/hide results if there are any matches
                if (matchCount > 0) {
                    search.removeClass(defaults.clsNoMatch);
                    showResults(results);
                }
                else {
                    search.addClass(defaults.clsNoMatch);
                    results.hide();
                }

                // Update the search attribute
                results.data('search', searchExpression);

                // Ensure the currently highlighted row always remains visible
                var highlighted = $('tr.' + defaults.clsHighlighted, results);
                if (highlighted.length > 0) {
                    if (highlighted.position().top > results.height()) {
                        var scrollOffset = highlighted.position().top - results.height() + highlighted.height();
                        results.scrollTop(results.scrollTop() + scrollOffset);
                    }
                }
            }
        };

        // Configure the state of the search control when focused/lost focus
        var configureSearchEvents = function (search, results, items) {
            search.focus(function () {
                // Clear the "select text" value
                if (search.hasClass(defaults.clsDefault)) {
                    search.val(null);
                }

                // Remove default class to ensure the correct style is applied
                search.removeClass(defaults.clsDefault);

                // Search
                performSearch(search, results, items);

                return true;
            });

            search.blur(function () {
                // Ensure the default class is added if empty
                if (search.val().length === 0) {
                    search.addClass(defaults.clsDefault);
                }

                // Add the "select text" value
                if (search.hasClass(defaults.clsDefault)) {
                    search.val(settings.selectText);
                    $(this).removeClass(defaults.clsNoMatch);
                }

                // Ensure no results are highlighted when focus is lost
                $('tr.' + defaults.clsHighlighted, results).each(function () {
                    $(this).removeClass(defaults.clsHighlighted);
                });

                // Check flag to determine if focusout was caused by 
                // clicking the scrollbar on the results
                if (!results.data('stay-open')) {
                    results.hide();
                }
                else {
                    results.data('stay-open', false);
                    search.focus();
                }
            });

            search.keydown(function (event) {
                // Get the currently highlighted item
                var highlighted = $('tr.' + defaults.clsHighlighted + ':visible', results);

                if (event.keyCode === 38 && highlighted.length > 0) { // UP ARROW
                    // Get the previous item excluding selected items
                    highlighted.prevAll().each(function () {
                        if (!$(this).hasClass(defaults.clsSelected) && $(this).is(':visible')) {
                            // Changing highlighting to the new item
                            highlighted.removeClass(defaults.clsHighlighted);
                            $(this).addClass(defaults.clsHighlighted);

                            // Ensure the item is visible
                            if ($(this).position().top < 0) {
                                results.scrollTop(results.scrollTop() - $(this).height());
                            }

                            return false;
                        }
                    });
                }
                else if (event.keyCode === 40) { // DOWN ARROW
                    if (highlighted.length === 0) {
                        // Select the first available item
                        $('tr:not(.' + defaults.clsSelected + '):visible:first', results).addClass(defaults.clsHighlighted);
                        results.scrollTop(0);
                    }
                    else {
                        // Get the next item excluding selected items
                        highlighted.nextAll().each(function () {

                            if (!$(this).hasClass(defaults.clsSelected) && $(this).is(':visible')) {
                                // Changing highlighting to the new item
                                highlighted.removeClass(defaults.clsHighlighted);
                                $(this).addClass(defaults.clsHighlighted);

                                // Ensure the item is visible
                                if ($(this).position().top > results.height()) {
                                    results.scrollTop(results.scrollTop() + $(this).height());
                                }

                                return false;
                            }
                        });
                    }
                }
                else if (event.keyCode === 13) { // ENTER
                    if (highlighted.length > 0) {
                        highlighted.trigger('mousedown');
                    }

                    return false;
                }
                else {
                    // Search
                    setTimeout(function () {
                        performSearch(search, results, items);
                    }, 0);
                }

                return true;
            });
        };

        return this.each(function () {
            // Create Elements
            var container = $('<div></div>').addClass(defaults.clsContainer).width(settings.width);
            var search = $('<input type="text"/>').addClass(defaults.clsSearch).addClass('form-control');
            var results = $('<div></div>').addClass(defaults.clsResults).data('search', null);
            var items = $('<div></div>').addClass(defaults.clsItems);

            if ($(this).hasClass("multiselectrequired")) {
                search.attr("data-val", "true");
                var errorMsg = $(this).attr("data-multiselectrequired-message") || "Please select an item";
                search.attr("data-val-multiselectrequired", errorMsg);
            }

            // Configure elements
            container.insertBefore(this);
            container.append(search);
            container.append(results);
            container.append(items);
            items.append(this);

            // Extracts the items and creates a pool of results for searching
            initialiseResults(search, results, items);

            // Clear search to set initial state
            clearSearch(search, results);

            // Configure events on the search input
            configureSearchEvents(search, results, items);
        });

    };
})(jQuery);