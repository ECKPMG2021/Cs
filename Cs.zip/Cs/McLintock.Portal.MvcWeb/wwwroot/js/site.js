﻿var mp = mp || {};

$(function () {
    mp.configureMultiselectControls();

    if (window.ClassicEditor) {
        ClassicEditor
            .create(document.querySelector('#editor'), {
                simpleUpload: {
                    // The URL the images are uploaded to.
                    //uploadUrl: '@Url.Action("Upload", "Image", null, "https")',
                    uploadUrl: "/image/Upload",

                    // Headers sent along with the XMLHttpRequest to the upload server.
                    //headers: {
                    //    'X-CSRF-TOKEN': '@Html.AntiForgeryToken()', // 'CSFR-Token',
                    //    // Authorization: 'Bearer <JSON Web Token>'
                    //}
                }
            })
            .then(editor => {
                console.log(editor);
                document.getElementById('pageLoaderModal').style.visibility = 'hidden';
            })
            .catch(error => {
                console.error(error);
            });

        //CKEDITOR.replace('editor', {
        //    on: {
        //        instanceReady: function (evt) {
        //            document.getElementById('loaderModal').style.visibility = 'hidden';
        //        }
        //    }
        //});
    }
});


mp.configureMultiselectControls = function configureMultiselectControls() {
    // Set default multi selects
    $('table.multiselect').multiSelect({
        'selectText': 'Click or type to select',
        'width': '100%'
    });
};
