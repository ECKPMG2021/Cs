using System;
using AutoMapper;
using McLintock.Portal.Core.Interfaces;
using McLintock.Portal.Core.Models;
using McLintock.Portal.Data.Entity;
using McLintock.Portal.Data.Identity;
using McLintock.Portal.Data.Repository;
using McLintock.Portal.MvcWeb.Security;
using McLintock.Portal.MvcWeb.Util;
using McLintock.Portal.Service.Mapping;
using McLintock.Portal.Service.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace McLintock.Portal.MvcWeb
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            services.AddDbContext<McLintockPortalContext>(options =>
                options.UseSqlServer(
                    Configuration.GetConnectionString("McLintockPortal")));

            //uncomment this if you want to use an in memory db instead. Using an in memory db will have side effects on some of the linq queries.
            //services.AddDbContext<McLintockPortalContext>(options =>
            //    options.UseInMemoryDatabase("McLintockPortal"));

            services.AddIdentity<ApplicationIdentityUser, ApplicationRole>(config =>
                {
                    config.SignIn.RequireConfirmedEmail = true;
                    config.User.RequireUniqueEmail = true;
                })
                .AddDefaultTokenProviders()
                .AddEntityFrameworkStores<McLintockPortalContext>();
 
            services.AddTransient<ISecurityConfig, MvcWebSecurityConfig>();

            services.AddScoped<IPostRepository, PostRepository>();
            services.AddScoped<IPostLogRepository, PostLogRepository>();
            services.AddScoped<ITagRepository, TagRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserGroupRepository, UserGroupRepository>();

            services.AddAutoMapper(typeof(MappingProfile));
            services.AddHttpContextAccessor();

            services.AddScoped<IPostService, PostService>();
            services.AddScoped<IPostLogService, PostLogService>();
            services.AddScoped<IService<UserGroupViewModel>, UserGroupService>();
            services.AddScoped<IStatsService, StatsService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            ConfigureDatabase(app, env);

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private void ConfigureDatabase(IApplicationBuilder app, IWebHostEnvironment env)
        {
            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<McLintockPortalContext>();
                context.Database.Migrate();

                if (env.IsDevelopment())
                {
                    var userManager = serviceScope.ServiceProvider.GetService<UserManager<ApplicationIdentityUser>>();
                    UserSeed.GenerateUsersAsync(userManager, context).GetAwaiter().GetResult();
                    DataSeed.Initialise(context);
                }
            }
        }

    }
}