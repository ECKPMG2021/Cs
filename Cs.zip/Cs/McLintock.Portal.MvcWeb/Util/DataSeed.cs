﻿namespace McLintock.Portal.MvcWeb.Util
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using McLintock.Portal.Data.Entity;

    /// <summary>
    /// Utility class to seed content for the site.
    /// </summary>
    public static class DataSeed
    {
        /// <summary>
        /// Add base content.
        /// </summary>
        /// <param name="context">McLintockPortalContext instance.</param>
        public static void Initialise(McLintockPortalContext context)
        {
            if (context.Posts.Any())
            {
                return;
            }

            context.Tags.AddRange(new List<Tag>
            {
                new Tag { Name = "Information" },
                new Tag { Name = "Food" },
                new Tag { Name = "History" },
                new Tag { Name = "Recipe" },
                new Tag { Name = "Sweet" },
            });

            context.UserGroups.AddRange(new List<UserGroup>
            {
                new UserGroup
                {
                    Name = "Cloud Team",
                    UserId = 1,
                    UserGroupMembers = new List<UserGroupMember>
                    {
                        new UserGroupMember { UserId = 2 },
                        new UserGroupMember { UserId = 3 },
                        new UserGroupMember { UserId = 4 },
                    },
                },
            });

            context.SaveChanges();

            context.Posts.AddRange(new List<Post>
            {
                new Post
                {
                    Title = "Intro To Veganism",
                    Content = "<figure class=\"image image-style-side\"><img src=\"https://www.ishtarskinlights.com/blog/wp-content/uploads/2015/03/rainbowaday.jpg?e2da7f&amp;e2da7f\" alt=\"eat a rainbow\"></figure><h2>What is veganism?<br>&nbsp;</h2><p>A lifestyle that avoids all animal foods such as meat, dairy, eggs and honey; animal derived products like leather; and, as far as possible, products tested on animals.</p><p>The Vegan Society’s formal definition is:&nbsp;<i>\"</i>veganism is a way of living which seeks to exclude, as far as is possible and practicable, all forms of exploitation of, and cruelty to, animals for food, clothing or any other purpose<i>.\"&nbsp;</i></p><h2>Veganism is a protected belief<br>&nbsp;</h2><p>Veganism is <a href=\"http://www.yourrights.org.uk/yourrights/the-human-rights-act/the-convention-rights/article-9-freedom-of-thought-conscience-and-religion.html\">protected</a> as a human right under <a href=\"http://conventions.coe.int/Treaty/en/Treaties/Html/005.htm\">Article 9</a> of the European Convention for the Protection of Human Rights.&nbsp;</p><h2>A vegan diet is recognised as a valid diet&nbsp;<br>&nbsp;</h2><p>Veganism is widely recognised as a valid, healthy diet that everyone can thrive on. The <a href=\"http://www.bda.uk.com/\">British Dietetic Association</a> recently stated that, <i>‘.</i>..well-planned plant-based, vegan-friendly diets can be devised to support healthy living at every age and life-stage.’ (Memorandum of Understanding between The Vegan Society and the British Dietetic Association,&nbsp;The British Dietetic Association,&nbsp;12th March 2014).</p><h2>How many vegans are there in Great Britain?<br>&nbsp;</h2><p>In 2018 The Vegan Society surveyed 2,000 people aged 15 or over across England, Scotland and Wales. We found the number of vegans in Britain has doubled <i>twice </i>in the past four years: from 0.25% (150,000) in 2014 to 0.46% (276,000) in 2016 to 1.16% in 2018 (600,000).</p><h2>Sale figures for vegan food products<br>&nbsp;</h2><p>The Mintel Meat-Free Foods UK Report for 2012 shows that meat-free and free-from sales are expected to reach a total of £949m in 2012 with meat-free sales set to reach £607m and free-from market sales expected to reach £342m.</p><p>Almost four in 10 (38%) Britons have bought vegetarian or meat-free food, while one in five (20%) has bought free-from food. The growth of the soya, rice and other alternatives to dairy milks as well as the dairy-free margarine market show the potential for this segment of the market.</p><h2>About The Vegan Society<br>&nbsp;</h2><p>The Vegan Society works to help more people become vegan with confidence, encourage more trusted Vegan Society Trademarked products to be available in shops, and take veganism to the mainstream. It provides information and guidance on various aspects of veganism for new and potential vegans, caterers, healthcare professionals, educators and the media. It also co-ordinates a variety of campaigns to raise awareness of the lifestyle.</p><p>The Vegan Society runs a mentoring scheme to help people who would like to become vegan called the <a href=\"https://www.vegansociety.com/try-vegan/get-support\">Vegan Pledge</a>. The number of Pledgers has doubled in the last year, with over 1000 people taking the Pledge each month.</p><p>Our multi-disciplinary <a href=\"https://www.vegansociety.com/society/whos-involved/research-advisory-committee\">Research Committee</a>&nbsp;consists of over 25 academics pursuing research on a range of topics within veganism. Please let us know if you wish to speak to a specialist and we will recommend someone.</p><p>The Vegan Society is the oldest vegan organisation in the world and was founded in 1944. At the establishment of the Society, founder Donald Watson and his wife coined the term ‘vegan’ to describe the lifestyle of what were then called the non-dairy vegetarians. The word ‘vegan’ was created from the first and last letters of ‘vegetarian’.</p><h2>When was the first vegan cookbook published?<br>&nbsp;</h2><p>The first animal-free cookery book,&nbsp;<i>Kitchen Philosophy for Vegetarians</i>,&nbsp;was published in England in 1849 by William Horsell of London. A review of the book claimed that “…butter and eggs are excluded” (<i>Vegetarian Advocate</i>, September 1849, p.10), making it the first known 'vegan' cookbook.</p><p>The first US vegan cookery book, entitled <i>The Hygeian Home Cook-Book; or, Healthful and Palatable Food Without Condiments</i>, was published in the USA in 1874 by Russell Thacher Trall, MD, a founding member of the American Vegetarian Society in 1850.</p><p>The first cookery book to use the new word ‘vegan’ in its title was Fay K. Henderson's <i>Vegan Recipes</i> published in 1946.</p>",
                    IsPublic = false,
                    CreatedByUserId = 1,
                    Created = new DateTime(2019, 8, 1, 15, 23, 06),
                    ModifiedByUserId = 1,
                    Modified = new DateTime(2019, 8, 1, 15, 23, 06),
                    PostTags = new List<PostTag>
                    {
                        new PostTag { TagId = 1 },
                        new PostTag { TagId = 3 },
                    },
                    PostUserGroups = new List<PostUserGroup>
                    {
                        new PostUserGroup { UserGroupId = 1 },
                    },
                },
                new Post
                {
                    Title = "Roasted Pumpkin Macaroni",
                    Content = "<figure class=\"image image-style-side\"><img src=\"/uploads/67cbd620-8dc2-49c4-b008-40a9f67f241d.jpg\"></figure><h2>This warming dish is the ultimate plant-based comfort food, made with Alpro Oat Unsweetened drink.<br>Makes 4 portions.</h2><p>&nbsp;</p><h3>Preparation</h3><p>&nbsp;</p><p>1. Preheat the oven to 180C. Cut the squash in half length-ways and scoop out and discard the seeds. Score the flesh with a cross hatch pattern using a sharp knife, brush lightly with a little oil, season generously with salt and pepper. Place on a parchment lined baking tray flesh side down and cook in the oven for 50-60 mins or until completely soft all the way through, you can check this by piercing the flesh with a knife.</p><p>2. Cook the pasta as per the packet instructions in seasoned water – Whilst the pasta is cooking, scoop the flesh from the butternut leaving the skin behind and place in a blender or processor along with the lemon juice, vegan parmesan, powdered garlic, mustard powder, 1 tbsp. extra virgin olive oil, Alpro Oat Unsweetened drink and nutmeg.&nbsp;</p><p>3. Heat the sauce through on the hob, adjusting the seasoning to taste with salt and pepper.</p><p>4. Heat the remaining tbsp. of olive oil in a small pan over a medium heat and fry the sage leaves and hazelnuts until crispy.</p><p>5. Mix the pasta into the sauce and spoon into bowls, top with the sage and hazelnuts to serve.</p><p>&nbsp;</p><h3>Ingredients</h3><p>&nbsp;</p><ul><li>1 butternut squash (around 1 kg)</li><li>2 tbsp lemon juice</li><li>75g grated vegan parmesan (or 15g Nutritional yeast flakes)</li><li>½ tsp powered garlic</li><li>1 tsp. mustard powder</li><li>1 tsp. grated nutmeg</li><li>300ml Alpro Oat Unsweetened drink</li><li>2 tbsp extra virgin olive oil, plus a little extra for oiling the squash</li><li>1 bunch of sage</li><li>100g hazelnuts, roughly chopped</li><li>400g macaroni</li><li>Salt and pepper</li></ul>",
                    IsPublic = true,
                    CreatedByUserId = 1,
                    Created = new DateTime(2019, 8, 1, 16, 23, 06),
                    ModifiedByUserId = 1,
                    Modified = new DateTime(2019, 8, 1, 16, 23, 06),
                    PostTags = new List<PostTag>
                    {
                        new PostTag { TagId = 2 },
                        new PostTag { TagId = 4 },
                    },
                },
                new Post
                {
                    Title = "Vegan Chocolate Chip Cookies",
                    Content = "<figure class=\"image image-style-side\"><img src=\"/uploads/3886fddd-c116-4f79-aca5-704f101c9155.jpg\"></figure><p>&nbsp;</p><h2>Makes 2 dozen 3-inch cookies</h2><p>&nbsp;</p><h3>Cooking&nbsp;Instructions</h3><p>&nbsp;</p><ol><li>Line baking sheets with parchment paper. Preheat the oven to 350 F.</li><li>In a medium bowl, whisk okara and all-purpose flours, baking powder, baking soda, and salt. Set aside.</li><li>In a large bowl, whisk the brown sugar with hot water. Add the coconut oil, almond butter, and vanilla and whisk until smooth. Stir in flour mixture. Stir in chocolate chips and nuts (if using).</li><li><i>*Baker’s Secret</i>: Cookies are extra delicious if you rest the dough for 1 hour or more before baking.</li><li>Place heaping tablespoons of dough 2” apart on lined pans. Bake 14-16 minutes in preheated oven, rotating pans half way, until cookies are golden brown. Set pans on a rack to cool.</li></ol><p>&nbsp;</p>",
                    IsPublic = true,
                    CreatedByUserId = 2,
                    Created = new DateTime(2019, 8, 1, 18, 23, 06),
                    ModifiedByUserId = 2,
                    Modified = new DateTime(2019, 8, 1, 18, 23, 06),
                    PostTags = new List<PostTag>
                    {
                        new PostTag { TagId = 2 },
                        new PostTag { TagId = 4 },
                        new PostTag { TagId = 5 },
                    },
                },
                new Post
                {
                    Title = "The Vegan Diet",
                    Content = "<figure class=\"image image-style-side\"><img src=\"/uploads/d5619365-c2db-4cd3-b72e-fddbfebb4046.jpg\"></figure><p>A vegan diet contains only plants (such as vegetables, grains, nuts and fruits) and foods made from plants.</p><p>Vegans do not eat foods that come from animals, including dairy products and eggs.</p><p>&nbsp;</p><h2>Healthy eating as a vegan</h2><p>You can get most of the nutrients you need from eating a varied and balanced vegan diet. &nbsp;</p><p>&nbsp;</p><h2>For a healthy vegan diet:</h2><p>&nbsp;</p><ul><li>eat at least 5 portions of a variety of fruit and vegetables every day</li><li>base meals on potatoes, bread, rice, pasta or other starchy carbohydrates (choose wholegrain where possible)</li><li>have some dairy alternatives, such as soya drinks and yoghurts (choose lower fat and lower sugar options)</li><li>eat some beans, pulses and other proteins</li><li>choose unsaturated oils and spreads, and eat in small amounts</li><li>drink plenty of fluids (the government recommends 6 to 8 cups or glasses a day)</li></ul><p>&nbsp;</p><p>If you choose to include foods and drinks that are high in fat, salt or sugar, have them less often and in small amounts.</p><p>See the Eatwell Guide for more information about a healthy diet. &nbsp;</p><p>The Eatwell Guide applies to vegetarians, vegans, people of all ethnic origins and those who are a healthy weight for their height, as well as those who are overweight.</p><p>The only group it's not suitable for is children under the age of 2, as they have different needs.</p><p>&nbsp;</p><h2>Getting the right nutrients from a vegan diet</h2><p>&nbsp;</p><p>With good planning and an understanding of what makes up a healthy, balanced vegan diet, you can get all the nutrients your body needs.</p><p>If you do not plan your diet properly, you could miss out on essential nutrients, such as calcium, iron and vitamin B12.</p>",
                    IsPublic = true,
                    CreatedByUserId = 2,
                    Created = new DateTime(2019, 8, 1, 19, 23, 06),
                    ModifiedByUserId = 2,
                    Modified = new DateTime(2019, 8, 1, 19, 23, 06),
                    PostTags = new List<PostTag>
                    {
                        new PostTag { TagId = 1 },
                    },
                },
            });

            context.SaveChanges();

            // Generate fake stats
            var postDate = DateTime.Now.AddDays(-30);
            var postRand = new Random();

            while (postDate <= DateTime.Today)
            {
                foreach (var post in context.Posts)
                {
                    for (int i = 0; i < postRand.Next(5, 20); i++)
                    {
                        context.PostLogs.Add(new PostLog
                        {
                            PostId = post.Id,
                            Timestamp = postDate.AddHours(i),
                            UserId = postRand.Next(1, 10),
                            Tags = post.PostTags.Select(t => new PostLogTag
                            {
                                TagId = t.TagId,
                            }).ToList(),
                        });
                    }
                }

                postDate = postDate.AddDays(1);
            }

            context.SaveChanges();
        }
    }
}
