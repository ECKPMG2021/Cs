﻿namespace McLintock.Portal.MvcWeb.Controllers
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Service.Services;
    using Microsoft.AspNetCore.Mvc;

    public class PostController : ControllerBase
    {
        private readonly IPostService _postService;
        private readonly IPostLogService _postLogService;

        public PostController(
            ISecurityConfig securityConfig,
            IPostService postService,
            IPostLogService postLogService)
            : base(securityConfig)
        {
            _postService = postService ?? throw new ArgumentNullException("postService");
            _postLogService = postLogService ?? throw new ArgumentNullException("postLogService");
        }

        // GET: Post
        public async Task<ActionResult> Index()
        {
            var model = await _postService.ListCreatedByUserAsync(SecurityConfig.UserId);

            return View(model);
        }

        // GET: Post/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var model = await _postService.DetailsAsync(id);
            model.Tags = model.Tags.Where(t => t.IsSelected).ToList();

            await LogPostViewAsync(model);

            return View(model);
        }

        // GET: Post/Create
        public async Task<ActionResult> Create()
        {
            var model = await _postService.CreateAsync();

            return View(model);
        }

        // POST: Post/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(PostViewModel model)
        {
            if (ModelState.IsValid && await _postService.CreateAsync(model))
            {
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: Post/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            var model = await _postService.EditAsync(id);

            return View(model);
        }

        // POST: Post/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(PostViewModel model)
        {
            if (ModelState.IsValid && await _postService.EditAsync(model))
            {
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: Post/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            var model = await _postService.EditAsync(id);

            return View(model);
        }

        // POST: Post/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(PostViewModel model)
        {
            if (await _postService.RemoveAsync(model.Id))
            {
                return RedirectToAction(nameof(Index));
            }
            else
            {
                ModelState.AddModelError(string.Empty, "There was a problem deleting the post.");
            }

            return View(model);
        }

        private async Task LogPostViewAsync(PostViewModel model)
        {
            var logModel = new PostLogViewModel
            {
                PostId = model.Id,
                Timestamp = DateTime.UtcNow,
                UserId = SecurityConfig.UserId,
                Tags = model.Tags.Select(t => new PostLogTagViewModel
                {
                    TagId = t.Id,
                }).ToList(),
            };

            try
            {
                await _postLogService.AddAsync(logModel);
            }
            catch (Exception)
            {
                return;
            }
        }
    }
}