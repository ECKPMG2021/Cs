﻿namespace McLintock.Portal.MvcWeb.Controllers
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    public class ImageController : Controller
    {
        private readonly IWebHostEnvironment _environment;

        public ImageController(IWebHostEnvironment webHostEnvironment)
        {
            _environment = webHostEnvironment ?? throw new ArgumentNullException(nameof(webHostEnvironment));
        }

        [HttpPost]
        public async Task<IActionResult> Upload()
        {
            var errorMsg = string.Empty;

            try
            {
                var formData = await Request.ReadFormAsync();

                if (formData.Files.Any())
                {
                    var upload = formData.Files.First();
                    var filename = $"{Guid.NewGuid().ToString()}{Path.GetExtension(upload.FileName)}";

                    var projDir = _environment.ContentRootPath;
                    var filepath = Path.Combine(projDir, "wwwroot\\uploads", filename);

                    using (var fs = new FileStream(filepath, FileMode.Create, FileAccess.Write))
                    {
                        await upload.CopyToAsync(fs);
                        await fs.FlushAsync();
                    }

                    return new JsonResult(new { url = Path.Combine("/uploads/", filename) });
                }
            }
            catch (Exception ex)
            {
                errorMsg = ex.Message;
            }

            return new JsonResult(new { error = new { message = $"Failed to upload image: {errorMsg}" } });
        }
    }
}