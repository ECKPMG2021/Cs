﻿namespace McLintock.Portal.MvcWeb.Controllers
{
    using System;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Service.Services;
    using Microsoft.AspNetCore.Mvc;

    public class UserGroupController : ControllerBase
    {
        private readonly IService<UserGroupViewModel> _userGroupService;

        public UserGroupController(
            ISecurityConfig securityConfig,
            IService<UserGroupViewModel> userGroupService)
            : base(securityConfig)
        {
            _userGroupService = userGroupService ?? throw new ArgumentNullException("userGroupService");
        }

        // GET: UserGroup
        public async Task<ActionResult> Index()
        {
            var model = await _userGroupService.ListAsync(SecurityConfig.UserId);

            return View(model);
        }

        // GET: UserGroup/Create
        public async Task<ActionResult> Create()
        {
            var model = await _userGroupService.CreateAsync();

            return View(model);
        }

        // POST: UserGroup/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(UserGroupViewModel model)
        {
            if (ModelState.IsValid && await _userGroupService.CreateAsync(model))
            {
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: UserGroup/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            var model = await _userGroupService.EditAsync(id);

            return View(model);
        }

        // POST: UserGroup/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(UserGroupViewModel model)
        {
            if (ModelState.IsValid && await _userGroupService.EditAsync(model))
            {
                return RedirectToAction(nameof(Index));
            }

            return View(model);
        }

        // GET: UserGroup/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            var model = await _userGroupService.EditAsync(id);

            return View(model);
        }

        // POST: UserGroup/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(UserGroupViewModel model)
        {
            if (await _userGroupService.RemoveAsync(model.Id))
            {
                return RedirectToAction(nameof(Index));
            }
            else
            {
                ModelState.AddModelError(string.Empty, "The user group cannot be deleted, check it hasn't been allocated to a post.");
            }

            return View(model);
        }
    }
}
