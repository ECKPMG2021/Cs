﻿using Microsoft.AspNetCore.Authorization;

namespace McLintock.Portal.MvcWeb.Controllers
{
    using System;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.MvcWeb.Models;
    using McLintock.Portal.Service.Services;
    using Microsoft.AspNetCore.Mvc;

    public class HomeController : ControllerBase
    {
        private readonly IPostService _postService;

        public HomeController(
            IPostService postService,
            ISecurityConfig securityConfig)
            : base(securityConfig)
        {
            _postService = postService ?? throw new ArgumentNullException("postService");
        }

        public async Task<IActionResult> Index(int? authorId = null, int? tagId = null)
        {
            var model = await _postService.SummaryListAsync(SecurityConfig.UserId, authorId, tagId);

            return View(model);
        }
        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
