﻿namespace McLintock.Portal.MvcWeb.Controllers
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Core.Interfaces;
    using McLintock.Portal.Core.Models;
    using McLintock.Portal.Service.Services;
    using Microsoft.AspNetCore.Mvc;

    public class StatsController : ControllerBase
    {
        private readonly IStatsService _statsService;

        public StatsController(
            ISecurityConfig securityConfig,
            IStatsService statsService)
            : base(securityConfig)
        {
            _statsService = statsService ?? throw new ArgumentNullException("statsService");
        }

        public async Task<IActionResult> Index(int days = 30)
        {
            var model = await _statsService.GetStatsAsync(days);

            return View(model);
        }

        public async Task<IActionResult> PostStats(int id, int days = 30)
        {
            var model = await _statsService.GetPostStatsAsync(id, days);
            var chartData = GetChartData(model);

            return new JsonResult(chartData);
        }

        public async Task<IActionResult> TagStats(int id, int days = 30)
        {
            var model = await _statsService.GetTagStatsAsync(id, days);
            var chartData = GetChartData(model);

            return new JsonResult(chartData);
        }

        private object GetChartData(StatsViewModel model)
        {
            var jsonModel = new
            {
                id = model.Id,
                name = model.Name,
                userstats = model.Items.Select(i => new
                {
                    x = i.Date.Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds,
                    y = i.Users,
                }),
                viewstats = model.Items.Select(i => new
                {
                    x = i.Date.Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds,
                    y = i.Views,
                }),
            };

            return jsonModel;
        }
    }
}