﻿namespace McLintock.Portal.MvcWeb.Controllers
{
    using McLintock.Portal.Core.Interfaces;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;

    [Authorize]
    public abstract class ControllerBase : Controller
    {
        public ControllerBase(ISecurityConfig securityConfig)
        {
            SecurityConfig = securityConfig;
        }

        protected ISecurityConfig SecurityConfig { get; }
    }
}
