﻿namespace McLintock.Portal.Data.Tests.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Identity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.TestHelpers;
    using Xunit;

    public class PostRepositoryTests
    {
        private McLintockPortalContext _context;
        private IPostRepository _repository;

        public PostRepositoryTests()
        {
            _context = InMemoryDb.GetMcLintockPortalContext();
            _repository = new PostRepository(_context);
        }

        [Fact]
        public async Task PostRepository_FillIn()
        {

        }
    }
}
