﻿namespace McLintock.Portal.Data.Tests.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.TestHelpers;
    using Xunit;

    public class TagRepositoryTests
    {
        private McLintockPortalContext _context;
        private ITagRepository _repository;

        public TagRepositoryTests()
        {
            _context = InMemoryDb.GetMcLintockPortalContext();
            _repository = new TagRepository(_context);
        }

        [Fact]
        public async Task TagRepository_GetByUserIdAsync_ReturnsCorrectData()
        {
            _context.Posts.AddRange(new List<Post>
            {
                new Post
                {
                    Id = 1,
                    Title = "P1",
                    Content = "P1-Content",
                    CreatedByUserId = 1,
                    ModifiedByUserId = 2,
                    PostTags = new List<PostTag>
                    {
                        new PostTag { Tag = new Tag { Id = 1, Name = "T1" } },
                    },
                },
                new Post
                {
                    Id = 2,
                    Title = "P2",
                    Content = "P2-Content",
                    CreatedByUserId = 2,
                    ModifiedByUserId = 1,
                    PostTags = new List<PostTag>
                    {
                        new PostTag { Tag = new Tag { Id = 2, Name = "T2" } },
                    },
                },
            });

            await _context.SaveChangesAsync();

            var result = await _repository.GetByUserIdAsync(1);

            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("T1", result.Single().Name);
        }
    }
}
