﻿namespace McLintock.Portal.Data.Tests.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using McLintock.Portal.Data.Entity;
    using McLintock.Portal.Data.Repository;
    using McLintock.Portal.TestHelpers;
    using Xunit;

    public class UserGroupRepositoryTests
    {
        private McLintockPortalContext _context;
        private IUserGroupRepository _repository;

        public UserGroupRepositoryTests()
        {
            _context = InMemoryDb.GetMcLintockPortalContext();
            _repository = new UserGroupRepository(_context);
        }

        [Fact]
        public async Task UserGroupRepository_GetByUserIdAsync_ReturnsCorrectData()
        {
            _context.UserGroups.AddRange(new List<UserGroup>
            {
                new UserGroup { Id = 1, Name = "G1", UserId = 1 },
                new UserGroup { Id = 2, Name = "G2", UserId = 2 },
            });

            await _context.SaveChangesAsync();

            var result = await _repository.GetByUserIdAsync(1);

            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("G1", result.Single().Name);
        }
    }
}
