﻿namespace McLintock.Portal.Core.Extensions
{
    using System;
    using McLintock.Portal.Core.Interfaces;

    /// <summary>
    /// Audit interface extensions.
    /// </summary>
    public static class AuditExtensions
    {
        /// <summary>
        /// Helper to update the audit information on an object.
        /// </summary>
        /// <param name="obj">The object to audit.</param>
        /// <param name="userId">The current user Id.</param>
        public static void Audit(this IAudit obj, int userId)
        {
            if (obj.CreatedByUserId == 0)
            {
                obj.Created = DateTime.UtcNow;
                obj.CreatedByUserId = userId;
            }

            obj.Modified = DateTime.UtcNow;
            obj.ModifiedByUserId = userId;
        }
    }
}
