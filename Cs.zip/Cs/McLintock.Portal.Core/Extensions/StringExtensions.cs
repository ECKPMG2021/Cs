﻿namespace McLintock.Portal.Core.Extensions
{
    using System.Globalization;

    /// <summary>
    /// String extension methods.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Removes and leading or trailing white space and convert to title casing.
        /// </summary>
        /// <param name="tagName">The tag name.</param>
        /// <returns>Standardised tag name.</returns>
        public static string ToTagStandard(this string tagName)
        {
            tagName = tagName.Trim();
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(tagName);
        }
    }
}
