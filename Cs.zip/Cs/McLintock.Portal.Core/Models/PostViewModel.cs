﻿namespace McLintock.Portal.Core.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    /// <summary>
    /// Post view model.
    /// </summary>
    public class PostViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PostViewModel"/> class.
        /// </summary>
        public PostViewModel()
        {
            IsPublic = true;
            Tags = new List<ItemSelectViewModel>();
            UserGroups = new List<ItemSelectViewModel>();
        }

        /// <summary>
        /// Gets or sets the post id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post title.
        /// </summary>
        [Required]
        [MaxLength(150)]
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the post content.
        /// </summary>
        [Required]
        public string Content { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the post is public.
        /// </summary>
        [Display(Name = "Public")]
        public bool IsPublic { get; set; }

        /// <summary>
        /// Gets or sets any new tags.
        /// </summary>
        [RegularExpression("[-a-zA-z0-9\r\n]{3,200}", ErrorMessage = "Only letters, numbers and hyphens are permitted")]
        public string NewTags { get; set; }

        /// <summary>
        /// Gets or sets the created by user name.
        /// </summary>
        [Display(Name = "Author")]
        public string CreatedByUserName { get; set; }

        /// <summary>
        /// Gets or sets the created time.
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:g}")]
        public DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the modified by user name.
        /// </summary>
        [Display(Name = "Modified By")]
        public string ModifiedByUserName { get; set; }

        /// <summary>
        /// Gets or sets the modified time.
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:g}")]
        public DateTime Modified { get; set; }

        /// <summary>
        /// Gets or sets the tag collection.
        /// </summary>
        public List<ItemSelectViewModel> Tags { get; set; }

        /// <summary>
        /// Gets or sets the user groups collection.
        /// </summary>
        public List<ItemSelectViewModel> UserGroups { get; set; }
    }
}
