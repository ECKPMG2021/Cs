﻿namespace McLintock.Portal.Core.Models
{
    /// <summary>
    /// Post log tag view model.
    /// </summary>
    public class PostLogTagViewModel
    {
        /// <summary>
        /// Gets or sets the tag Id.
        /// </summary>
        public int TagId { get; set; }

        /// <summary>
        /// Gets or sets the tag name.
        /// </summary>
        public string TagName { get; set; }
    }
}
