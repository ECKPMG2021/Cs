﻿namespace McLintock.Portal.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Stats page view model.
    /// </summary>
    public class StatsPageViewModel
    {
        /// <summary>
        /// Gets or sets the post select list items.
        /// </summary>
        public List<ItemSelectViewModel> PostSelectListItems { get; set; }

        /// <summary>
        /// Gets or sets the tag select list items.
        /// </summary>
        public List<ItemSelectViewModel> TagSelectListItems { get; set; }
    }
}
