﻿namespace McLintock.Portal.Core.Models
{
    using System;

    /// <summary>
    /// Stats item view model.
    /// </summary>
    public class StatsItemViewModel
    {
        /// <summary>
        /// Gets or sets the date.
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets the number of views.
        /// </summary>
        public int Views { get; set; }

        /// <summary>
        /// Gets or sets the number of users.
        /// </summary>
        public int Users { get; set; }
    }
}
