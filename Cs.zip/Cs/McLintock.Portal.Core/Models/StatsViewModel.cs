﻿namespace McLintock.Portal.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Stats view model.
    /// </summary>
    public class StatsViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatsViewModel"/> class.
        /// </summary>
        public StatsViewModel()
        {
            Items = new List<StatsItemViewModel>();
        }

        /// <summary>
        /// Gets or sets the post id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the stats items.
        /// </summary>
        public List<StatsItemViewModel> Items { get; set; }
    }
}
