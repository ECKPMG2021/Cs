﻿namespace McLintock.Portal.Core.Models
{
    using McLintock.Portal.Core.Interfaces;

    /// <summary>
    /// Security configuration.
    /// </summary>
    public class SecurityConfig : ISecurityConfig
    {
        /// <inheritdoc/>
        public int UserId { get; set; }
    }
}
