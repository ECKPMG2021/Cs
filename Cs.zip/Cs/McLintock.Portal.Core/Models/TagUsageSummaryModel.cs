﻿namespace McLintock.Portal.Core.Models
{
    /// <summary>
    /// Tag usage summary model.
    /// </summary>
    public class TagUsageSummaryModel
    {
        /// <summary>
        /// Gets or sets the tag Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the tag name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the number of posts the tag is associated with.
        /// </summary>
        public int Posts { get; set; }

        /// <summary>
        /// Gets or sets the number of views the tag has had.
        /// </summary>
        public int Views { get; set; }

        /// <summary>
        /// Gets or sets the number of unique users that have viewed the tag.
        /// </summary>
        public int Users { get; set; }
    }
}
