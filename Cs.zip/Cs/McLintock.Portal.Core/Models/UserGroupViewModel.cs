﻿namespace McLintock.Portal.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// User group view model.
    /// </summary>
    public class UserGroupViewModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserGroupViewModel"/> class.
        /// </summary>
        public UserGroupViewModel()
        {
            Users = new List<ItemSelectViewModel>();
        }

        /// <summary>
        /// Gets or sets the user group id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the user group name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the user id.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the users collection.
        /// </summary>
        public List<ItemSelectViewModel> Users { get; set; }
    }
}
