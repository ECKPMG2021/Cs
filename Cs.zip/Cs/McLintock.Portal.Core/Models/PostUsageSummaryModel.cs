﻿namespace McLintock.Portal.Core.Models
{
    /// <summary>
    /// Post usage summary model.
    /// </summary>
    public class PostUsageSummaryModel
    {
        /// <summary>
        /// Gets or sets the post Id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the post title.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the number of views the post has had.
        /// </summary>
        public int Views { get; set; }

        /// <summary>
        /// Gets or sets the number of unique users that have viewed the post.
        /// </summary>
        public int Users { get; set; }
    }
}
