﻿namespace McLintock.Portal.Core.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Post log view model.
    /// </summary>
    public class PostLogViewModel
    {
        /// <summary>
        /// Gets or sets the author Id.
        /// </summary>
        public int AuthorId { get; set; }

        /// <summary>
        /// Gets or sets the author name.
        /// </summary>
        public string AuthorName { get; set; }

        /// <summary>
        /// Gets or sets the user post Id.
        /// </summary>
        public int PostId { get; set; }

        /// <summary>
        /// Gets or sets the post title.
        /// </summary>
        public string PostTitle { get; set; }

        /// <summary>
        /// Gets or sets the view time.
        /// </summary>
        public DateTime Timestamp { get; set; }

        /// <summary>
        /// Gets or sets the user Id.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// Gets or sets the user name.
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets the post tags at the time of viewing.
        /// </summary>
        public List<PostLogTagViewModel> Tags { get; set; }
    }
}
