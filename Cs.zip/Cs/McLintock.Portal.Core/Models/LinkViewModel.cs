﻿namespace McLintock.Portal.Core.Models
{
    /// <summary>
    /// Helper model for creating links.
    /// </summary>
    public class LinkViewModel
    {
        /// <summary>
        /// Gets or sets the Url.
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// Gets or sets the link text.
        /// </summary>
        public string LinkText { get; set; }
    }
}
