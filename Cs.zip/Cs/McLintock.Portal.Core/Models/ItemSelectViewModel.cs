﻿namespace McLintock.Portal.Core.Models
{
    /// <summary>
    /// Item select view model.
    /// </summary>
    public class ItemSelectViewModel
    {
        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the tag name.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the tag has been selected.
        /// </summary>
        public bool IsSelected { get; set; }
    }
}
