﻿namespace McLintock.Portal.Core.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Post summary view model.
    /// </summary>
    public class PostSummaryViewModel
    {
        /// <summary>
        /// Gets or sets the posts.
        /// </summary>
        public List<PostViewModel> Posts { get; set; }

        /// <summary>
        /// Gets or sets the top posts.
        /// </summary>
        public List<LinkViewModel> TopPosts { get; set; }

        /// <summary>
        /// Gets or sets the top authors.
        /// </summary>
        public List<LinkViewModel> TopAuthors { get; set; }

        /// <summary>
        /// Gets or sets the top tags.
        /// </summary>
        public List<LinkViewModel> TopTags { get; set; }
    }
}
