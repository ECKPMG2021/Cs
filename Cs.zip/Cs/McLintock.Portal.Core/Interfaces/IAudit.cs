﻿namespace McLintock.Portal.Core.Interfaces
{
    using System;

    /// <summary>
    /// IAudit interface, used to track who made changes to an object.
    /// </summary>
    public interface IAudit
    {
        /// <summary>
        /// Gets or sets the created by user id.
        /// </summary>
        int CreatedByUserId { get; set; }

        /// <summary>
        /// Gets or sets the created time.
        /// </summary>
        DateTime Created { get; set; }

        /// <summary>
        /// Gets or sets the modified by user id.
        /// </summary>
        int ModifiedByUserId { get; set; }

        /// <summary>
        /// Gets or sets the modified time.
        /// </summary>
        DateTime Modified { get; set; }
    }
}
