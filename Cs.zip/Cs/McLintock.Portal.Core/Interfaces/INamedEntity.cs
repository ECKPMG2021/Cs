﻿namespace McLintock.Portal.Core.Interfaces
{
    /// <summary>
    /// Name entity interface.
    /// </summary>
    public interface INamedEntity
    {
        /// <summary>
        /// Gets or sets the name of the entity.
        /// </summary>
        string Name { get; set; }
    }
}
