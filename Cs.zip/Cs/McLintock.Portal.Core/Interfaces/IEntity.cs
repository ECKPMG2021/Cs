﻿namespace McLintock.Portal.Core.Interfaces
{
    /// <summary>
    /// IEntity interface.
    /// </summary>
    public interface IEntity
    {
        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        int Id { get; set; }
    }
}
