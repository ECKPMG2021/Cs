﻿namespace McLintock.Portal.Core.Interfaces
{
    /// <summary>
    /// Security configuration.
    /// </summary>
    public interface ISecurityConfig
    {
        /// <summary>
        /// Gets or sets the current users Id.
        /// </summary>
        int UserId { get; set; }
    }
}
